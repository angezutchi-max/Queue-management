<?php
/**
 * controllers/MedecinController.php
 * Contrôleur pour l'espace Médecin – Version mono-service avec utilisateurs
 */

require_once __DIR__ . '/../models/MedecinModel.php';
require_once __DIR__ . '/../models/ServiceModel.php';
require_once __DIR__ . '/../models/UtilisateurModel.php';
require_once __DIR__ . '/../helpers/UploadHelper.php';
require_once __DIR__ . '/../helpers/AuthHelper.php';

class MedecinController
{
    private MedecinModel $model;
    private ServiceModel $serviceModel;
    private UtilisateurModel $utilisateurModel;

    public function __construct()
    {
        $this->model = new MedecinModel();
        $this->serviceModel = new ServiceModel();
        $this->utilisateurModel = new UtilisateurModel();
    }

    /* ════════════════════════════════════════════════════════
       INSCRIPTION (mono‑service)
    ════════════════════════════════════════════════════════ */

    public function afficherInscription(): void
    {
        // Vérifier si déjà connecté comme médecin
        if (AuthHelper::estMedecin()) {
            header('Location: medecin.php?action=dashboard');
            exit;
        }
        
        $sousServices = $this->model->getSousServicesActifs();
        $erreurs    = [];
        $anciens    = [];
        require __DIR__ . '/../views/medecin/inscription.php';
    }

    public function traiterInscription(): void
    {
        $sousServices = $this->model->getSousServicesActifs();
        $erreurs  = [];

        $nom       = trim($_POST['nom']        ?? '');
        $prenom    = trim($_POST['prenom']      ?? '');
        $telephone = trim($_POST['telephone']   ?? '');
        $email     = trim($_POST['email']       ?? '');
        $password  = $_POST['password']         ?? '';
        $confirm   = $_POST['confirm']          ?? '';
        $specialiteId = (int)($_POST['sous_service_id'] ?? 0);

        $anciens = compact('nom', 'prenom', 'telephone', 'email', 'specialiteId');

        // Upload de la photo
        $photoPath = null;
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $upload = UploadHelper::uploadPhoto($_FILES['photo'], 'medecins');
            if ($upload['success']) {
                $photoPath = $upload['filename'];
            } else {
                $erreurs['photo'] = $upload['error'];
            }
        }

        // Validations
        if (mb_strlen($nom) < 2) $erreurs['nom'] = 'Nom trop court (min. 2 caractères).';
        if (mb_strlen($prenom) < 2) $erreurs['prenom'] = 'Prénom trop court (min. 2 caractères).';

        if (!preg_match('/^\+?[0-9]{8,19}$/', $telephone)) {
            $erreurs['telephone'] = 'Numéro invalide (chiffres et + uniquement).';
        } elseif ($this->model->telephoneExiste($telephone)) {
            $erreurs['telephone'] = 'Ce numéro est déjà utilisé.';
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $erreurs['email'] = 'Adresse email invalide.';
        } elseif ($this->model->emailExiste($email)) {
            $erreurs['email'] = 'Cette adresse email est déjà utilisée.';
        } elseif ($this->utilisateurModel->emailExiste($email)) {
            $erreurs['email'] = 'Cette adresse email est déjà utilisée dans le système.';
        }

        if ($specialiteId <= 0) {
            $erreurs['sous_service_id'] = 'Veuillez sélectionner votre sous-service.';
        } else {
            $ss = $this->model->trouverSousServiceParId($specialiteId);
            if (!$ss || $ss['statut'] !== 'actif') {
                $erreurs['sous_service_id'] = 'Sous‑service invalide.';
            }
        }

        if (strlen($password) < 8) {
            $erreurs['password'] = 'Minimum 8 caractères.';
        } elseif (!preg_match('/[A-Z]/', $password)) {
            $erreurs['password'] = 'Au moins une majuscule requise.';
        } elseif (!preg_match('/[0-9]/', $password)) {
            $erreurs['password'] = 'Au moins un chiffre requis.';
        }

        if ($password !== $confirm) $erreurs['confirm'] = 'Les mots de passe ne correspondent pas.';

        if (!empty($erreurs)) {
            require __DIR__ . '/../views/medecin/inscription.php';
            return;
        }

        // 🔐 Hacher le mot de passe une seule fois ici.
        //    MedecinModel::creer() reçoit le hash et le stocke tel quel.
        //    UtilisateurModel::creerAvecHashExistant() stocke le même hash.
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

        // 1. Créer le médecin (creer() retourne bool, pas l'ID)
        $ok = $this->model->creer([
            'nom'        => $nom,
            'prenom'     => $prenom,
            'specialite' => $ss['nom'],
            'telephone'  => $telephone,
            'email'      => $email,
            'password'   => $hashedPassword,
            'photo'      => $photoPath,
        ]);

        if (!$ok) {
            $erreurs['global'] = 'Erreur lors de la création du compte médecin.';
            require __DIR__ . '/../views/medecin/inscription.php';
            return;
        }

        // model->creer() retourne bool — récupérer l'ID séparément
        $medecinId = $this->model->dernierID();

        // 2. Affecter le sous-service
        $this->model->affecterSousService($medecinId, $specialiteId);

        // 3. Créer le compte utilisateur avec le même hash (pas de 2e hachage)
        $userId = $this->utilisateurModel->creerAvecHashExistant([
            'email'      => $email,
            'mot_de_passe' => $hashedPassword,
            'role'       => 'medecin',
            'nom'        => $prenom . ' ' . $nom,
            'medecin_id' => $medecinId,
        ]);

        if (!$userId) {
            $erreurs['global'] = 'Erreur lors de la création du compte utilisateur.';
            require __DIR__ . '/../views/medecin/inscription.php';
            return;
        }

        // 4. Connecter avec le vrai user_id (table utilisateurs) + medecin_id séparé
        AuthHelper::initSession();
        $_SESSION['user_id']       = $userId;        // ID dans `utilisateurs`
        $_SESSION['user_nom']      = $prenom . ' ' . $nom;
        $_SESSION['user_email']    = $email;
        $_SESSION['medecin_id']    = $medecinId;     // ID dans `medecins`
        $_SESSION['role']          = 'medecin';
        $_SESSION['last_activity'] = time();

        header('Location: medecin.php?action=dashboard');
        exit;
    }

    /* ════════════════════════════════════════════════════════
       CONNEXION
    ════════════════════════════════════════════════════════ */

    public function afficherConnexion(): void
    {
        if (AuthHelper::estMedecin()) {
            header('Location: medecin.php?action=dashboard');
            exit;
        }
        
        $erreurs      = [];
        $ancien_email = '';
        require __DIR__ . '/../views/medecin/connexion.php';
    }

    public function traiterConnexion(): void
    {
        $erreurs      = [];
        $ancien_email = trim($_POST['email']  ?? '');
        $password     = $_POST['password']    ?? '';

        if (empty($ancien_email) || empty($password)) {
            $erreurs['global'] = 'Veuillez remplir tous les champs.';
            require __DIR__ . '/../views/medecin/connexion.php';
            return;
        }

        // Authentifier via la table utilisateurs
        $user = $this->utilisateurModel->authentifier($ancien_email, $password);

        if (!$user || ($user['role'] !== 'medecin' && $user['role'] !== 'admin')) {
            $erreurs['global'] = 'Email ou mot de passe incorrect.';
            require __DIR__ . '/../views/medecin/connexion.php';
            return;
        }

        // Vérifier que le médecin existe
        $medecin = $this->model->trouverParId($user['medecin_id']);
        if (!$medecin) {
            $erreurs['global'] = 'Compte médecin introuvable.';
            require __DIR__ . '/../views/medecin/connexion.php';
            return;
        }

        // Mettre à jour la dernière connexion
        $this->utilisateurModel->updateDerniereConnexion($user['id']);

        // Stocker le vrai user_id (table utilisateurs) + medecin_id séparé
        AuthHelper::initSession();
        $_SESSION['user_id']       = $user['id'];          // ID dans `utilisateurs`
        $_SESSION['user_nom']      = $user['nom'];
        $_SESSION['user_email']    = $user['email'];
        $_SESSION['medecin_id']    = $user['medecin_id']; // ID dans `medecins`
        $_SESSION['role']          = $user['role'];
        $_SESSION['last_activity'] = time();

        header('Location: medecin.php?action=dashboard');
        exit;
    }

    /* ════════════════════════════════════════════════════════
       DASHBOARD
    ════════════════════════════════════════════════════════ */

    public function afficherDashboard(): void
    {
        if (!AuthHelper::peutAccederEspaceMedecin()) {
            header('Location: medecin.php?action=connexion');
            exit;
        }

        $medecinId  = (int)$_SESSION['medecin_id'];
        $medecin    = $this->model->trouverParId($medecinId);
        $affectation = $this->model->getSousServiceMedecin($medecinId);
        
        // Récupérer les jours de travail du médecin
        $medecin['jours_travail'] = $this->model->getJoursTravailMedecin($medecinId);
        
        // Récupérer les horaires du service (id=1)
        $service = $this->serviceModel->getServiceById(1);
        if (!$service) {
            $this->serviceModel->creerServiceParDefaut();
            $service = $this->serviceModel->getServiceById(1);
        }
        
        $stats      = [];
        $consultations = [];
        $planning   = [];

        if ($affectation) {
            $ssId = (int)$affectation['ss_id'];
            $stats = $this->model->statsJour($ssId);
            $consultations = $this->model->consultationsDuJour($ssId, $medecinId);
            $planning = $this->model->planningMedecin($medecinId);
        }

        require __DIR__ . '/../views/medecin/dashboard.php';
    }

    /* ════════════════════════════════════════════════════════
       DÉCONNEXION
    ════════════════════════════════════════════════════════ */

    public function deconnecter(): void
    {
        session_unset();
        session_destroy();
        header('Location: accueil.php');
        exit;
    }
    
    // ═══════════════════════════════════════════════════════════════════════════════
    // MÉTHODES AJAX (getConsultationsData, getStatsData, etc.) - Inchangées
    // ═══════════════════════════════════════════════════════════════════════════════
    
    public function getConsultationsData(): void
    {
        header('Content-Type: application/json');

        if (!AuthHelper::peutAccederEspaceMedecin()) {
            echo json_encode(['error' => 'Non authentifié']);
            exit;
        }

        $medecinId = $_SESSION['medecin_id'];
        $affectation = $this->model->getSousServiceMedecin($medecinId);

        if (!$affectation) {
            echo json_encode(['success' => true, 'consultations' => [], 'stats' => []]);
            exit;
        }

        $ssId = $affectation['ss_id'];
        $consultations = $this->model->consultationsDuJour($ssId, $medecinId);
        $stats = $this->model->statsJour($ssId);

        foreach ($consultations as &$c) {
            $c['heure_passage_estimee'] = $c['heure_passage_estimee'] ? date('H:i', strtotime($c['heure_passage_estimee'])) : '—';
            $c['heure_debut_reelle'] = $c['heure_debut_reelle'] ? date('H:i', strtotime($c['heure_debut_reelle'])) : '—';
            $c['heure_fin_reelle'] = $c['heure_fin_reelle'] ? date('H:i', strtotime($c['heure_fin_reelle'])) : '—';
        }

        echo json_encode(['success' => true, 'consultations' => $consultations, 'stats' => $stats]);
        exit;
    }

    public function getStatsData(): void
    {
        header('Content-Type: application/json');

        if (!AuthHelper::peutAccederEspaceMedecin()) {
            echo json_encode(['error' => 'Non authentifié']);
            exit;
        }

        $medecinId = $_SESSION['medecin_id'];
        $affectation = $this->model->getSousServiceMedecin($medecinId);

        if (!$affectation) {
            echo json_encode(['success' => true, 'stats' => []]);
            exit;
        }

        $stats = $this->model->statsJour($affectation['ss_id']);
        echo json_encode(['success' => true, 'stats' => $stats]);
        exit;
    }

    public function demarrerConsultationAjax(): void
    {
        header('Content-Type: application/json');

        if (!AuthHelper::peutAccederEspaceMedecin()) {
            echo json_encode(['success' => false, 'message' => 'Non authentifié']);
            exit;
        }

        $consultationId = (int)($_POST['consultation_id'] ?? 0);
        if ($consultationId && $this->model->demarrerConsultation($consultationId)) {
            echo json_encode(['success' => true, 'message' => 'Consultation démarrée']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Impossible de démarrer cette consultation']);
        }
        exit;
    }

    public function terminerConsultationAjax(): void
    {
        header('Content-Type: application/json');

        if (!AuthHelper::peutAccederEspaceMedecin()) {
            echo json_encode(['success' => false, 'message' => 'Non authentifié']);
            exit;
        }

        $consultationId = (int)($_POST['consultation_id'] ?? 0);
        if ($consultationId && $this->model->terminerConsultation($consultationId)) {
            echo json_encode(['success' => true, 'message' => 'Consultation terminée']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Impossible de terminer cette consultation']);
        }
        exit;
    }

    public function marquerAbsentAjax(): void
    {
        header('Content-Type: application/json');

        if (!AuthHelper::peutAccederEspaceMedecin()) {
            echo json_encode(['success' => false, 'message' => 'Non authentifié']);
            exit;
        }

        $consultationId = (int)($_POST['consultation_id'] ?? 0);
        if ($consultationId && $this->model->marquerAbsent($consultationId)) {
            echo json_encode(['success' => true, 'message' => 'Patient marqué comme absent']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Impossible de marquer ce patient comme absent']);
        }
        exit;
    }

    public function annulerToutesAjax(): void
    {
        header('Content-Type: application/json');

        if (!AuthHelper::peutAccederEspaceMedecin()) {
            echo json_encode(['success' => false, 'message' => 'Non authentifié']);
            exit;
        }

        $medecinId = $_SESSION['medecin_id'];
        if ($this->model->annulerToutesConsultations($medecinId)) {
            echo json_encode(['success' => true, 'message' => 'Toutes les consultations ont été annulées']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erreur lors de l\'annulation']);
        }
        exit;
    }

    public function getPlanningMedecin(): void
    {
        header('Content-Type: application/json');

        if (!AuthHelper::peutAccederEspaceMedecin()) {
            echo json_encode(['error' => 'Non authentifié']);
            exit;
        }

        $medecinId = $_SESSION['medecin_id'];
        $affectation = $this->model->getSousServiceMedecin($medecinId);

        if (!$affectation) {
            echo json_encode(['success' => true, 'consultations' => []]);
            exit;
        }

        $ssId = $affectation['ss_id'];
        $date = $_GET['date'] ?? date('Y-m-d');
        $startDate = date('Y-m-d', strtotime($date));
        $endDate = date('Y-m-d', strtotime($date . ' +6 days'));

        $consultationsData = $this->model->getConsultationsParPeriode($ssId, $medecinId, $startDate, $endDate);
        
        $consultations = [];
        foreach ($consultationsData as $c) {
            $consultations[] = [
                'id' => $c['id'],
                'patient_nom' => $c['patient_nom'],
                'patient_prenom' => $c['patient_prenom'],
                'statut' => $c['statut'],
                'heure_debut' => date('H:i', strtotime($c['heure_passage_estimee'])),
                'date_consultation' => date('Y-m-d', strtotime($c['heure_passage_estimee']))
            ];
        }

        echo json_encode([
            'success' => true,
            'consultations' => $consultations,
            'date_debut' => $date
        ]);
        exit;
    }

    public function getProfilData(): void
    {
        header('Content-Type: application/json');

        if (!AuthHelper::peutAccederEspaceMedecin()) {
            echo json_encode(['success' => false, 'message' => 'Non authentifié']);
            exit;
        }

        $medecinId = $_SESSION['medecin_id'];
        $medecin = $this->model->trouverParId($medecinId);

        if (!$medecin) {
            echo json_encode(['success' => false, 'message' => 'Utilisateur non trouvé']);
            exit;
        }

        echo json_encode([
            'success' => true,
            'profil' => [
                'nom' => $medecin['nom'],
                'prenom' => $medecin['prenom'],
                'telephone' => $medecin['telephone'],
                'email' => $medecin['email'],
                'photo' => $medecin['photo']
            ]
        ]);
        exit;
    }

    public function mettreAJourProfil(): void
    {
        header('Content-Type: application/json');

        if (!AuthHelper::peutAccederEspaceMedecin()) {
            echo json_encode(['success' => false, 'message' => 'Non authentifié']);
            exit;
        }

        $id = $_SESSION['medecin_id'];
        $nom = trim($_POST['nom'] ?? '');
        $prenom = trim($_POST['prenom'] ?? '');
        $telephone = trim($_POST['telephone'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $passwordActuel = $_POST['password_actuel'] ?? '';
        $nouveauPassword = $_POST['nouveau_password'] ?? '';
        $confirmerPassword = $_POST['confirmer_password'] ?? '';

        $erreurs = [];

        if (mb_strlen($nom) < 2) $erreurs['nom'] = 'Nom trop court.';
        if (mb_strlen($prenom) < 2) $erreurs['prenom'] = 'Prénom trop court.';
        if (!preg_match('/^\+?[0-9]{8,19}$/', $telephone)) $erreurs['telephone'] = 'Téléphone invalide.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $erreurs['email'] = 'Email invalide.';

        $medecin = $this->model->trouverParId($id);
        if ($email !== $medecin['email'] && $this->model->emailExiste($email)) {
            $erreurs['email'] = 'Cet email est déjà utilisé.';
        }
        if ($telephone !== $medecin['telephone'] && $this->model->telephoneExiste($telephone)) {
            $erreurs['telephone'] = 'Ce numéro est déjà utilisé.';
        }

        // Gestion de la photo
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $upload = UploadHelper::uploadPhoto($_FILES['photo'], 'medecins');
            if ($upload['success']) {
                if ($medecin['photo'] && file_exists(__DIR__ . '/../' . $medecin['photo'])) {
                    unlink(__DIR__ . '/../' . $medecin['photo']);
                }
                $this->model->mettreAJourPhoto($id, $upload['filename']);
            } else {
                $erreurs['photo'] = $upload['error'];
            }
        }

        if (!empty($nouveauPassword)) {
            if (empty($passwordActuel)) {
                $erreurs['password_actuel'] = 'Veuillez entrer votre mot de passe actuel.';
            } elseif (!$this->model->verifierMotDePasse($id, $passwordActuel)) {
                $erreurs['password_actuel'] = 'Mot de passe actuel incorrect.';
            } elseif (strlen($nouveauPassword) < 8) {
                $erreurs['nouveau_password'] = 'Minimum 8 caractères.';
            } elseif (!preg_match('/[A-Z]/', $nouveauPassword)) {
                $erreurs['nouveau_password'] = 'Au moins une majuscule.';
            } elseif (!preg_match('/[0-9]/', $nouveauPassword)) {
                $erreurs['nouveau_password'] = 'Au moins un chiffre.';
            } elseif ($nouveauPassword !== $confirmerPassword) {
                $erreurs['confirmer_password'] = 'Les mots de passe ne correspondent pas.';
            }
        }

        if (!empty($erreurs)) {
            echo json_encode(['success' => false, 'errors' => $erreurs]);
            exit;
        }

        $this->model->mettreAJourProfil($id, $nom, $prenom, $telephone);

        // Récupérer l'utilisateur AVANT de changer l'email dans medecins
        $user = $this->utilisateurModel->findByEmail($medecin['email']);

        $this->model->mettreAJourEmail($id, $email);

        // Synchroniser dans utilisateurs
        if ($user) {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare('UPDATE utilisateurs SET email = :email, nom = :nom WHERE id = :id');
            $stmt->execute([
                ':email' => $email,
                ':nom'   => $prenom . ' ' . $nom,
                ':id'    => $user['id'],
            ]);
        }

        if (!empty($nouveauPassword)) {
            // MedecinModel::mettreAJourMotDePasse() hache lui-même → passer le mot de passe en clair
            $this->model->mettreAJourMotDePasse($id, $nouveauPassword);
            // Synchroniser dans utilisateurs avec le même hash
            $hash = password_hash($nouveauPassword, PASSWORD_BCRYPT, ['cost' => 12]);
            if ($user) {
                $db = Database::getInstance()->getConnection();
                $stmt = $db->prepare('UPDATE utilisateurs SET mot_de_passe = :password WHERE id = :id');
                $stmt->execute([':password' => $hash, ':id' => $user['id']]);
            }
        }

        $_SESSION['user_nom'] = $prenom . ' ' . $nom;

        echo json_encode(['success' => true, 'message' => 'Profil mis à jour avec succès.']);
        exit;
    }
    
    public function apiSousServices(): void
    {
        header('Content-Type: application/json');
        $sousServices = $this->model->getSousServicesActifs();
        echo json_encode($sousServices);
        exit;
    }
}