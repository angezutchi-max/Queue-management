<?php
/**
 * controllers/MedecinController.php
 * Un seul type de compte médecin — inscription simple avec hôpital + sous-service
 */
require_once __DIR__ . '/../models/MedecinModel.php';

class MedecinController
{
    private MedecinModel $model;

    public function __construct()
    {
        $this->model = new MedecinModel();
    }

    /* ══════ INSCRIPTION ══════ */

    public function afficherInscription(): void
    {
        $erreurs    = [];
        $anciens    = [];
        $services   = $this->model->getServices();
        require __DIR__ . '/../views/medecin/inscription.php';
    }

    public function traiterInscription(): void
    {
        $erreurs  = [];
        $services = $this->model->getServices();

        $nom       = trim($_POST['nom']        ?? '');
        $prenom    = trim($_POST['prenom']      ?? '');
        $telephone = trim($_POST['telephone']   ?? '');
        $email     = trim($_POST['email']       ?? '');
        $password  = $_POST['password']         ?? '';
        $confirm   = $_POST['confirm']          ?? '';
        $serviceId = (int)($_POST['service_id'] ?? 0);
        $specialite= trim($_POST['specialite']  ?? ''); // nom du sous-service choisi

        $anciens = compact('nom','prenom','telephone','email','serviceId','specialite');

        /* ── Validation ── */
        if (mb_strlen($nom)    < 2) $erreurs['nom']    = 'Nom trop court (min. 2 caractères).';
        if (mb_strlen($prenom) < 2) $erreurs['prenom'] = 'Prénom trop court (min. 2 caractères).';

        if (!preg_match('/^\+?[0-9]{8,19}$/', $telephone))
            $erreurs['telephone'] = 'Numéro invalide (chiffres et + uniquement).';
        elseif ($this->model->telephoneExiste($telephone))
            $erreurs['telephone'] = 'Ce numéro est déjà utilisé.';

        if (!filter_var($email, FILTER_VALIDATE_EMAIL))
            $erreurs['email'] = 'Adresse email invalide.';
        elseif ($this->model->emailExiste($email))
            $erreurs['email'] = 'Cette adresse email est déjà utilisée.';

        if ($serviceId === 0)
            $erreurs['service_id'] = 'Veuillez sélectionner un hôpital.';

        if (empty($specialite))
            $erreurs['specialite'] = 'Veuillez sélectionner votre sous-service.';

        $sousServiceId = 0;
        if ($serviceId > 0 && !empty($specialite)) {
            $sousServiceId = $this->model->trouverSousServiceParNom($specialite, $serviceId);
            if (!$sousServiceId)
                $erreurs['specialite'] = 'Sous-service introuvable. Veuillez resélectionner.';
        }

        if (strlen($password) < 8)
            $erreurs['password'] = 'Minimum 8 caractères.';
        elseif (!preg_match('/[A-Z]/', $password))
            $erreurs['password'] = 'Au moins une majuscule requise.';
        elseif (!preg_match('/[0-9]/', $password))
            $erreurs['password'] = 'Au moins un chiffre requis.';

        if ($password !== $confirm)
            $erreurs['confirm'] = 'Les mots de passe ne correspondent pas.';

        if (!empty($erreurs)) {
            require __DIR__ . '/../views/medecin/inscription.php';
            return;
        }

        /* ── Création du compte ── */
        $ok = $this->model->creer([
            'nom'        => $nom,
            'prenom'     => $prenom,
            'specialite' => $specialite,
            'telephone'  => $telephone,
            'email'      => $email,
            'password'   => $password,
            'service_id' => $serviceId,
        ]);

        if (!$ok) {
            $erreurs['global'] = 'Erreur lors de la création du compte. Veuillez réessayer.';
            require __DIR__ . '/../views/medecin/inscription.php';
            return;
        }

        $medecinId = $this->model->dernierID();

        // Affectation directe au sous-service choisi
        $this->model->affecterSousService($medecinId, $sousServiceId);

        header('Location: medecin.php?action=connexion&inscription=succes');
        exit;
    }

    /* ══════ CONNEXION ══════ */

    public function afficherConnexion(): void
    {
        $erreurs      = [];
        $ancien_email = '';
        require __DIR__ . '/../views/medecin/connexion.php';
    }

    public function traiterConnexion(): void
    {
        $erreurs      = [];
        $ancien_email = trim($_POST['email']  ?? '');
        $password     = $_POST['password']    ?? '';

        if (empty($ancien_email) || empty($password)) {
            $erreurs['global'] = 'Veuillez remplir tous les champs.';
            require __DIR__ . '/../views/medecin/connexion.php';
            return;
        }

        $medecin = $this->model->trouverParEmail($ancien_email);

        if (!$medecin || !password_verify($password, $medecin['password'])) {
            $erreurs['global'] = 'Email ou mot de passe incorrect.';
            require __DIR__ . '/../views/medecin/connexion.php';
            return;
        }

        session_regenerate_id(true);
        $_SESSION['medecin_id']     = $medecin['id'];
        $_SESSION['medecin_nom']    = $medecin['nom'] . ' ' . $medecin['prenom'];
        $_SESSION['medecin_prenom'] = $medecin['prenom'];
        $_SESSION['last_activity']  = time();

        header('Location: medecin.php?action=dashboard');
        exit;
    }

    /* ══════ DASHBOARD ══════ */

    public function afficherDashboard(): void
    {
        if (!isset($_SESSION['medecin_id'])) {
            header('Location: medecin.php?action=connexion');
            exit;
        }

        $medecinId  = (int)$_SESSION['medecin_id'];
        $medecinNom = $_SESSION['medecin_nom'];

        $affectation  = $this->model->getSousServiceMedecin($medecinId);
        $stats        = [];
        $consultations= [];
        $planning     = [];
        $messageAction= '';
        $typeMessage  = 'success';

        if ($affectation) {
            $ssId          = (int)$affectation['ss_id'];
            $stats         = $this->model->statsJour($ssId);
            $consultations = $this->model->consultationsDuJour($ssId, $medecinId);
            $planning      = $this->model->planningMedecin($medecinId);
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = $_POST['action'] ?? '';

            if ($action === 'maj_statut') {
                $cId    = (int)($_POST['consultation_id'] ?? 0);
                $statut = $_POST['statut'] ?? '';
                if ($cId > 0 && in_array($statut, ['en_cours','traite','absent','annule'])) {
                    $this->model->majStatutConsultation($cId, $statut);
                    $messageAction = 'Statut mis à jour.';
                }
            }

            if ($affectation) {
                $ssId          = (int)$affectation['ss_id'];
                $stats         = $this->model->statsJour($ssId);
                $consultations = $this->model->consultationsDuJour($ssId, $medecinId);
            }
        }

        require __DIR__ . '/../views/medecin/dashboard.php';
    }

    /* ══════ API AJAX ══════ */

    public function apiSousServices(): void
    {
        header('Content-Type: application/json; charset=utf-8');
        $serviceId = (int)($_GET['service_id'] ?? 0);
        if ($serviceId <= 0) { echo json_encode([]); exit; }
        echo json_encode($this->model->getSousServicesActifsParService($serviceId));
        exit;
    }

    /* ══════ DÉCONNEXION ══════ */

    public function deconnecter(): void
    {
        session_unset();
        session_destroy();
        header('Location: medecin.php?action=connexion&deconnecte=1');
        exit;
    }
}

/* ── Dispatch ── */
$action = $_GET['action'] ?? 'connexion';
$ok     = ['inscription','connexion','dashboard','deconnexion','api_sous_services'];

if (!in_array($action, $ok)) {
    header('Location: medecin.php?action=connexion'); exit;
}

$ctrl = new MedecinController();
match ($action) {
    'inscription'       => $_SERVER['REQUEST_METHOD'] === 'POST' ? $ctrl->traiterInscription()  : $ctrl->afficherInscription(),
    'connexion'         => $_SERVER['REQUEST_METHOD'] === 'POST' ? $ctrl->traiterConnexion()     : $ctrl->afficherConnexion(),
    'dashboard'         => $ctrl->afficherDashboard(),
    'deconnexion'       => $ctrl->deconnecter(),
    'api_sous_services' => $ctrl->apiSousServices(),
    default             => $ctrl->afficherConnexion(),
};
