<?php
echo "<style>body{font-family:monospace;padding:20px} .ko{color:red} .ok{color:green}</style>";

$files = [
    'GestionnaireController' => __DIR__ . '/controllers/GestionnaireController.php',
    'MedecinController'      => __DIR__ . '/controllers/MedecinController.php',
    'UtilisateurModel'       => __DIR__ . '/models/UtilisateurModel.php',
];

foreach ($files as $name => $path) {
    echo "<h3>$name</h3><pre>";
    $lines = file($path);
    foreach ($lines as $i => $line) {
        if (preg_match('/hash|password|creer|mot_de_passe/i', $line)) {
            $cls = strpos($line, 'hashedPassword') !== false ? 'ko' : '';
            echo "<span class='$cls'>" . ($i+1) . ": " . htmlspecialchars($line) . "</span>";
        }
    }
    echo "</pre>";
}

// Test direct connexion gestionnaire
echo "<h3>Test connexion directe</h3>";
require_once __DIR__ . '/config/database.php';
$db = Database::getInstance()->getConnection();

$email = $_GET['email'] ?? '';
$password = $_GET['password'] ?? '';

if ($email && $password) {
    $stmt = $db->prepare("SELECT * FROM utilisateurs WHERE email = :e AND statut = 'actif'");
    $stmt->execute([':e' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo "<p class='ko'>❌ Aucun utilisateur actif avec cet email.</p>";
    } else {
        echo "<p>Utilisateur : <b>{$user['nom']}</b> | rôle : <b>{$user['role']}</b></p>";
        echo "<p>Hash (60 cars attendus) : longueur = <b>" . strlen($user['mot_de_passe']) . "</b></p>";
        $ok = password_verify($password, $user['mot_de_passe']);
        echo $ok
            ? "<p class='ok'>✅ password_verify = TRUE → connexion devrait marcher</p>"
            : "<p class='ko'>❌ password_verify = FALSE → hash corrompu en base</p>";

        if (!$ok) {
            echo "<p>→ Utiliser debug3.php pour forcer le reset du mot de passe.</p>";
        }
    }
}
?>
<form method="GET">
  Email : <input name="email" style="width:260px"><br><br>
  MDP   : <input name="password" style="width:200px"><br><br>
  <button>Tester connexion</button>
</form>
