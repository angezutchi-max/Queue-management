-- ================================================================
-- À EXÉCUTER UNE SEULE FOIS dans phpMyAdmin ou ligne de commande
-- pour corriger le comptage des médecins
-- ================================================================

-- Étape 1 : Ajouter service_id dans la table medecins
ALTER TABLE `medecins`
  ADD COLUMN IF NOT EXISTS `service_id` INT UNSIGNED NULL
  COMMENT 'Service hospitalier auquel appartient le médecin'
  AFTER `telephone`;

-- Étape 2 : Remplir service_id pour les médecins déjà en BD
-- (remonte via medecin_sous_service → sous_services → services)
UPDATE `medecins` m
SET m.service_id = (
    SELECT ss.service_id
    FROM medecin_sous_service mss
    JOIN sous_services ss ON ss.id = mss.sous_service_id
    WHERE mss.medecin_id = m.id
    LIMIT 1
)
WHERE m.service_id IS NULL;

-- Étape 3 : Supprimer est_chef si elle existe encore
ALTER TABLE `medecin_sous_service`
  DROP COLUMN IF EXISTS `est_chef`;

-- ================================================================
-- Vérification : affiche le nb de médecins par service
-- ================================================================
SELECT s.nom AS service, COUNT(m.id) AS nb_medecins
FROM services s
LEFT JOIN medecins m ON m.service_id = s.id
GROUP BY s.id, s.nom;
