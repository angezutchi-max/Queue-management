-- ================================================================
-- MIGRATION : Suppression du concept chef/ordinaire
-- À exécuter UNE SEULE FOIS sur votre base de données
-- ================================================================

-- 1. Supprimer la colonne est_chef de medecin_sous_service
--    (garde la table mais sans distinction de rôle)
ALTER TABLE `medecin_sous_service`
  DROP COLUMN IF EXISTS `est_chef`;

-- 2. Si la contrainte de clé primaire inclut est_chef, la recréer sans
--    (uniquement si l'étape 1 échoue — à adapter selon votre version MySQL)
-- ALTER TABLE `medecin_sous_service` DROP PRIMARY KEY;
-- ALTER TABLE `medecin_sous_service` ADD PRIMARY KEY (`medecin_id`, `sous_service_id`);

-- 3. Supprimer le champ service_id_chef s'il existe dans medecins
--    (ajouté dans une version précédente, inutile désormais)
ALTER TABLE `medecins`
  DROP COLUMN IF EXISTS `service_id`;

-- 4. Nettoyer les sessions PHP en attente (table sessions si vous en avez une)
-- DELETE FROM sessions WHERE data LIKE '%chef_service_id_pending%';

-- 5. Vérification : tous les médecins doivent avoir un sous-service
SELECT
  m.id,
  CONCAT(m.nom, ' ', m.prenom) AS medecin,
  m.email,
  COUNT(mss.sous_service_id) AS nb_affectations
FROM medecins m
LEFT JOIN medecin_sous_service mss ON mss.medecin_id = m.id
GROUP BY m.id, m.nom, m.prenom, m.email
HAVING nb_affectations = 0;
-- Les médecins affichés ci-dessus n'ont pas de sous-service → à affecter manuellement

-- ================================================================
