<?php
echo "<h3>GestionnaireController — traiterInscription (lignes 39-130)</h3><pre>";
$lines = file(__DIR__ . '/controllers/GestionnaireController.php');
echo htmlspecialchars(implode('', array_slice($lines, 38, 90)));
echo "</pre>";
