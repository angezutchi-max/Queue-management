<?php
echo "<h3>GestionnaireController sur disque — autour du mot de passe</h3><pre>";
$lines = file(__DIR__ . '/controllers/GestionnaireController.php');
// Chercher les lignes avec 'hash' ou 'password' dans traiterInscription
foreach ($lines as $i => $line) {
    if (stripos($line, 'hash') !== false || stripos($line, 'creer') !== false) {
        echo ($i+1) . ": " . htmlspecialchars($line);
    }
}
echo "</pre>";

echo "<h3>MedecinController sur disque — autour du mot de passe</h3><pre>";
$lines2 = file(__DIR__ . '/controllers/MedecinController.php');
foreach ($lines2 as $i => $line) {
    if (stripos($line, 'hash') !== false || stripos($line, 'creer') !== false) {
        echo ($i+1) . ": " . htmlspecialchars($line);
    }
}
echo "</pre>";

echo "<h3>UtilisateurModel::creer sur disque</h3><pre>";
$lines3 = file(__DIR__ . '/models/UtilisateurModel.php');
$inCreer = false;
foreach ($lines3 as $i => $line) {
    if (strpos($line, 'public function creer') !== false) $inCreer = true;
    if ($inCreer) {
        echo ($i+1) . ": " . htmlspecialchars($line);
        if ($inCreer && strpos($line, '}') !== false && $i > 60) break;
    }
}
echo "</pre>";
