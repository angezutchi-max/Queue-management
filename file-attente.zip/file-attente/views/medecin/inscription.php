<?php // views/medecin/inscription.php ?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inscription Médecin — QueueCare</title>
  <link rel="preconnect" href="https://fonts.bunny.net">
  <link href="https://fonts.bunny.net/css?family=playfair-display:400,500,700,400i,700i|outfit:300,400,500,600,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
  <link rel="stylesheet" href="public/css/style.css">
  <link rel="stylesheet" href="public/css/medecin.css">
  <script src="../../public/js/auto-dismiss.js" defer></script>
</head>
<body class="med-auth-body">
<div class="med-auth-wrapper">

  <!-- Panneau gauche -->
  <aside class="med-brand">
    <div class="med-brand-inner">
      <div class="med-logo anim-fade-up">
        <span class="med-logo-icon"><i class="fa-solid fa-user-doctor"></i></span>
        <span class="med-logo-name">QueueCare</span>
      </div>
      <div class="med-brand-body anim-fade-up-1">
        <h1 class="med-brand-title">Rejoignez<br><em>l'équipe médicale.</em></h1>
        <p class="med-brand-sub">Créez votre espace médecin pour gérer vos consultations et votre planning.</p>
      </div>
      <ul class="med-features anim-fade-up-2">
        <li><i class="fa-solid fa-circle-check"></i> Suivi des consultations en temps réel</li>
        <li><i class="fa-solid fa-circle-check"></i> Planning hebdomadaire intégré</li>
        <li><i class="fa-solid fa-circle-check"></i> Estimation dynamique du temps d'attente</li>
        <li><i class="fa-solid fa-circle-check"></i> Gestion des urgences médicales</li>
      </ul>
      <div class="med-brand-deco">
        <div class="med-deco-ring med-deco-ring-1"></div>
        <div class="med-deco-ring med-deco-ring-2"></div>
        <div class="med-deco-dot med-deco-dot-1"></div>
        <div class="med-deco-dot med-deco-dot-2"></div>
      </div>
    </div>
  </aside>

  <!-- Panneau droit -->
  <main class="med-form-panel">
    <div class="med-form-inner anim-fade-up">

      <div class="med-form-header">
        <a href="accueil.php" style="display:inline-flex;align-items:center;gap:6px;font-size:.8rem;color:var(--text-muted);margin-bottom:14px;text-decoration:none;" onmouseover="this.style.color='var(--blue)'" onmouseout="this.style.color='var(--text-muted)'">
          <i class="fa-solid fa-arrow-left fa-xs"></i> Retour à l'accueil
        </a><br>
        <span class="badge badge-blue"><i class="fa-solid fa-user-doctor"></i>&nbsp; Espace Médecin</span>
        <h2 class="med-title">Créer un compte</h2>
        <p class="med-subtitle">
          Déjà inscrit ?
          <a href="medecin.php?action=connexion" class="link-blue">
            Se connecter <i class="fa-solid fa-arrow-right fa-xs"></i>
          </a>
        </p>
      </div>

      <?php if (!empty($erreurs['global'])): ?>
      <div class="alert alert-error">
        <i class="fa-solid fa-triangle-exclamation"></i> <?= htmlspecialchars($erreurs['global']) ?>
      </div>
      <?php endif; ?>

      <form method="POST" action="medecin.php?action=inscription"
            class="med-form" id="medecinForm" novalidate>

        <!-- Nom / Prénom -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
          <div class="field <?= isset($erreurs['nom']) ? 'field--error' : '' ?>">
            <label class="field-label" for="nom"><i class="fa-solid fa-user fa-xs"></i> Nom *</label>
            <div class="field-wrap">
              <span class="field-icon"><i class="fa-solid fa-user"></i></span>
              <input type="text" id="nom" name="nom" class="field-input"
                placeholder="Dupont"
                value="<?= htmlspecialchars($anciens['nom'] ?? '') ?>" required>
            </div>
            <?php if (isset($erreurs['nom'])): ?>
            <span class="field-error"><i class="fa-solid fa-circle-exclamation fa-xs"></i> <?= htmlspecialchars($erreurs['nom']) ?></span>
            <?php endif; ?>
          </div>
          <div class="field <?= isset($erreurs['prenom']) ? 'field--error' : '' ?>">
            <label class="field-label" for="prenom"><i class="fa-solid fa-user fa-xs"></i> Prénom *</label>
            <div class="field-wrap">
              <span class="field-icon"><i class="fa-solid fa-user"></i></span>
              <input type="text" id="prenom" name="prenom" class="field-input"
                placeholder="Jean"
                value="<?= htmlspecialchars($anciens['prenom'] ?? '') ?>" required>
            </div>
            <?php if (isset($erreurs['prenom'])): ?>
            <span class="field-error"><i class="fa-solid fa-circle-exclamation fa-xs"></i> <?= htmlspecialchars($erreurs['prenom']) ?></span>
            <?php endif; ?>
          </div>
        </div>

        <!-- Téléphone -->
        <div class="field <?= isset($erreurs['telephone']) ? 'field--error' : '' ?>">
          <label class="field-label" for="telephone"><i class="fa-solid fa-phone fa-xs"></i> Téléphone *</label>
          <div class="field-wrap">
            <span class="field-icon"><i class="fa-solid fa-phone"></i></span>
            <input type="tel" id="telephone" name="telephone" class="field-input"
              placeholder="+237699123456"
              value="<?= htmlspecialchars($anciens['telephone'] ?? '') ?>"
              pattern="[0-9+]+" inputmode="tel" required>
          </div>
          <small style="color:var(--text-light);font-size:.72rem;margin-top:2px;">
            <i class="fa-solid fa-circle-info fa-xs"></i> Chiffres et le signe + uniquement
          </small>
          <?php if (isset($erreurs['telephone'])): ?>
          <span class="field-error"><i class="fa-solid fa-circle-exclamation fa-xs"></i> <?= htmlspecialchars($erreurs['telephone']) ?></span>
          <?php endif; ?>
        </div>

        <!-- Email -->
        <div class="field <?= isset($erreurs['email']) ? 'field--error' : '' ?>">
          <label class="field-label" for="email"><i class="fa-solid fa-envelope fa-xs"></i> Email *</label>
          <div class="field-wrap">
            <span class="field-icon"><i class="fa-solid fa-envelope"></i></span>
            <input type="email" id="email" name="email" class="field-input"
              placeholder="medecin@hopital.cm"
              value="<?= htmlspecialchars($anciens['email'] ?? '') ?>" required>
          </div>
          <?php if (isset($erreurs['email'])): ?>
          <span class="field-error"><i class="fa-solid fa-circle-exclamation fa-xs"></i> <?= htmlspecialchars($erreurs['email']) ?></span>
          <?php endif; ?>
        </div>

        <!-- Hôpital -->
        <div class="field <?= isset($erreurs['service_id']) ? 'field--error' : '' ?>">
          <label class="field-label" for="service_id">
            <i class="fa-solid fa-hospital fa-xs"></i> Hôpital / Service *
          </label>
          <div class="field-wrap">
            <span class="field-icon"><i class="fa-solid fa-hospital"></i></span>
            <select id="service_id" name="service_id" class="field-input field-select">
              <option value="" disabled selected>Sélectionner l'hôpital</option>
              <?php foreach ($services as $s): ?>
              <option value="<?= (int)$s['id'] ?>"
                <?= (int)($anciens['serviceId'] ?? 0) === (int)$s['id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($s['nom']) ?>
              </option>
              <?php endforeach; ?>
            </select>
            <span class="select-arrow"><i class="fa-solid fa-chevron-down"></i></span>
          </div>
          <?php if (isset($erreurs['service_id'])): ?>
          <span class="field-error"><i class="fa-solid fa-circle-exclamation fa-xs"></i> <?= htmlspecialchars($erreurs['service_id']) ?></span>
          <?php endif; ?>
        </div>

        <!-- Spécialité / Sous-service -->
        <div class="field <?= isset($erreurs['specialite']) ? 'field--error' : '' ?>">
          <label class="field-label" for="specialite">
            <i class="fa-solid fa-stethoscope fa-xs"></i> Spécialité / Sous-service *
          </label>
          <div class="field-wrap" style="position:relative;">
            <span class="field-icon"><i class="fa-solid fa-stethoscope"></i></span>
            <select id="specialite" name="specialite" class="field-input field-select" disabled>
              <option value="" disabled selected>— Choisissez d'abord l'hôpital —</option>
            </select>
            <span class="select-arrow"><i class="fa-solid fa-chevron-down"></i></span>
            <span id="ssLoading" style="display:none;position:absolute;right:36px;top:50%;transform:translateY(-50%);">
              <i class="fa-solid fa-spinner fa-spin" style="color:#1a4db5;font-size:.85rem;"></i>
            </span>
          </div>
          <small style="color:var(--text-light);font-size:.72rem;margin-top:2px;">
            <i class="fa-solid fa-circle-info fa-xs"></i>
            Choisissez d'abord l'hôpital pour voir les sous-services disponibles.
          </small>
          <?php if (isset($erreurs['specialite'])): ?>
          <span class="field-error"><i class="fa-solid fa-circle-exclamation fa-xs"></i> <?= htmlspecialchars($erreurs['specialite']) ?></span>
          <?php endif; ?>
        </div>

        <!-- Mot de passe -->
        <div class="field <?= isset($erreurs['password']) ? 'field--error' : '' ?>">
          <label class="field-label" for="password"><i class="fa-solid fa-lock fa-xs"></i> Mot de passe *</label>
          <div class="field-wrap">
            <span class="field-icon"><i class="fa-solid fa-lock"></i></span>
            <input type="password" id="password" name="password" class="field-input"
              placeholder="Min. 8 car., 1 maj., 1 chiffre"
              autocomplete="new-password" required>
            <button type="button" class="toggle-pw" id="togglePw">
              <i class="fa-solid fa-eye" id="eyeIcon"></i>
            </button>
          </div>
          <div class="pw-strength">
            <div class="pw-bar"><div class="pw-fill" id="pwFill"></div></div>
            <span class="pw-label" id="pwLabel"></span>
          </div>
          <?php if (isset($erreurs['password'])): ?>
          <span class="field-error"><i class="fa-solid fa-circle-exclamation fa-xs"></i> <?= htmlspecialchars($erreurs['password']) ?></span>
          <?php endif; ?>
        </div>

        <!-- Confirmation -->
        <div class="field <?= isset($erreurs['confirm']) ? 'field--error' : '' ?>">
          <label class="field-label" for="confirm"><i class="fa-solid fa-shield-halved fa-xs"></i> Confirmer le mot de passe *</label>
          <div class="field-wrap">
            <span class="field-icon"><i class="fa-solid fa-shield-halved"></i></span>
            <input type="password" id="confirm" name="confirm" class="field-input"
              placeholder="Répéter le mot de passe" autocomplete="new-password" required>
          </div>
          <?php if (isset($erreurs['confirm'])): ?>
          <span class="field-error"><i class="fa-solid fa-circle-exclamation fa-xs"></i> <?= htmlspecialchars($erreurs['confirm']) ?></span>
          <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-blue btn-full btn-lg" id="submitBtn">
          <i class="fa-solid fa-user-plus"></i> Créer mon compte
        </button>

      </form>

      <p class="med-legal">
        En vous inscrivant, vous acceptez les <a href="#">conditions d'utilisation</a>
        et la <a href="#">politique de confidentialité</a>.
      </p>

    </div>
  </main>
</div>

<script>
var API_SS = 'medecin.php?action=api_sous_services&service_id=';
var selService = document.getElementById('service_id');
var selSpec    = document.getElementById('specialite');
var ssLoading  = document.getElementById('ssLoading');
var ancienVal  = <?= json_encode($anciens['specialite'] ?? '') ?>;

selService.addEventListener('change', function() {
  loadSousServices(this.value);
});

function loadSousServices(serviceId) {
  if (!serviceId) { resetSelect('— Choisissez d\'abord l\'hôpital —'); return; }
  ssLoading.style.display = '';
  selSpec.disabled = true;

  var xhr = new XMLHttpRequest();
  xhr.open('GET', API_SS + encodeURIComponent(serviceId), true);
  xhr.onload = function() {
    ssLoading.style.display = 'none';
    try {
      var data = JSON.parse(xhr.responseText);
      selSpec.innerHTML = '';
      if (!data || !data.length) {
        selSpec.innerHTML = '<option value="" disabled selected>Aucun sous-service disponible</option>';
        selSpec.disabled = true;
      } else {
        var def = document.createElement('option');
        def.value = ''; def.disabled = true; def.selected = true;
        def.textContent = 'Sélectionner votre spécialité';
        selSpec.appendChild(def);
        data.forEach(function(ss) {
          var opt = document.createElement('option');
          opt.value = ss.nom;
          opt.textContent = ss.nom + (ss.capacite_horaire ? '  (' + ss.capacite_horaire + '/h)' : '');
          if (ancienVal && opt.value === ancienVal) opt.selected = true;
          selSpec.appendChild(opt);
        });
        selSpec.disabled = false;
      }
    } catch(e) { resetSelect('Erreur — réessayez'); }
  };
  xhr.onerror = function() { ssLoading.style.display = 'none'; resetSelect('Erreur — réessayez'); };
  xhr.send();
}

function resetSelect(msg) {
  selSpec.innerHTML = '<option value="" disabled selected>' + msg + '</option>';
  selSpec.disabled = true;
}

// Restaurer après erreur de validation
<?php if (!empty($anciens['serviceId'])): ?>
loadSousServices(<?= (int)$anciens['serviceId'] ?>);
<?php endif; ?>

// Toggle mot de passe
var pwInput = document.getElementById('password');
document.getElementById('togglePw').addEventListener('click', function() {
  var show = pwInput.type === 'password';
  pwInput.type = show ? 'text' : 'password';
  document.getElementById('eyeIcon').className = show ? 'fa-solid fa-eye-slash' : 'fa-solid fa-eye';
});

// Force mot de passe
pwInput.addEventListener('input', function() {
  var v = pwInput.value, s = 0;
  if (v.length >= 8)           s++;
  if (/[A-Z]/.test(v))         s++;
  if (/[0-9]/.test(v))         s++;
  if (/[^A-Za-z0-9]/.test(v))  s++;
  var lvl = [{w:'0%',c:'',t:''},{w:'25%',c:'#ef4444',t:'Très faible'},
             {w:'50%',c:'#f59e0b',t:'Faible'},{w:'75%',c:'#2563eb',t:'Moyen'},
             {w:'100%',c:'#1a8a52',t:'Fort'}];
  document.getElementById('pwFill').style.width = lvl[s].w;
  document.getElementById('pwFill').style.backgroundColor = lvl[s].c;
  document.getElementById('pwLabel').textContent = lvl[s].t;
  document.getElementById('pwLabel').style.color = lvl[s].c;
});

// Téléphone
document.getElementById('telephone').addEventListener('input', function() {
  this.value = this.value.replace(/[^0-9+]/g, '');
});

// Soumission
document.getElementById('medecinForm').addEventListener('submit', function(e) {
  var pw = document.getElementById('password').value;
  var cf = document.getElementById('confirm').value;
  if (pw !== cf) {
    e.preventDefault();
    document.getElementById('confirm').style.borderColor = '#ef4444';
    document.getElementById('confirm').focus();
    return;
  }
  var btn = document.getElementById('submitBtn');
  setTimeout(function() { btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Création…'; btn.disabled = true; }, 50);
});
</script>
</body>
</html>
