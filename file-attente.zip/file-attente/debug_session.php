<?php
// Capturer TOUT ce qui est émis avant session_start
ob_start();

require_once __DIR__ . '/helpers/AuthHelper.php';

$output = ob_get_clean();

echo "<style>body{font-family:monospace;padding:20px} .ko{color:red} .ok{color:green}</style>";
echo "<h3>Output capturé AVANT session_start</h3>";
if ($output) {
    echo "<pre class='ko'>" . htmlspecialchars($output) . "</pre>";
    echo "<p class='ko'>⛔ Ces sorties empêchent session_start() de fonctionner.</p>";
} else {
    echo "<p class='ok'>✅ Aucun output avant session_start — la session peut démarrer.</p>";
}

echo "<h3>Session démarrée ?</h3>";
echo "session_status() = " . session_status() . " (1=inactif, 2=actif)<br>";
echo session_status() === PHP_SESSION_ACTIVE
    ? "<p class='ok'>✅ Session active — ID : " . session_id() . "</p>"
    : "<p class='ko'>❌ Session inactive</p>";

echo "<h3>Test authentifier direct</h3>";
require_once __DIR__ . '/models/UtilisateurModel.php';
$m = new UtilisateurModel();

$email    = $_GET['email']    ?? '';
$password = $_GET['password'] ?? '';

if ($email && $password) {
    $user = $m->authentifier($email, $password);
    if ($user) {
        echo "<p class='ok'>✅ authentifier() retourne : <pre>" . print_r($user, true) . "</pre></p>";
        echo "<p>role = <b>{$user['role']}</b> " . ($user['role'] === 'gestionnaire' ? "✅" : "❌ pas 'gestionnaire'") . "</p>";
    } else {
        echo "<p class='ko'>❌ authentifier() retourne false</p>";

        // Vérifier manuellement
        require_once __DIR__ . '/config/database.php';
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT id, email, statut, role, LENGTH(mot_de_passe) as hlen FROM utilisateurs WHERE email = :e");
        $stmt->execute([':e' => $email]);
        $row = $stmt->fetch();
        if ($row) {
            echo "<pre>" . print_r($row, true) . "</pre>";
            // Fetch full hash
            $stmt2 = $db->prepare("SELECT mot_de_passe FROM utilisateurs WHERE email = :e");
            $stmt2->execute([':e' => $email]);
            $h = $stmt2->fetchColumn();
            echo "password_verify direct : " . (password_verify($password, $h) ? "<span class='ok'>TRUE</span>" : "<span class='ko'>FALSE</span>") . "<br>";
        } else {
            echo "<p class='ko'>Aucun utilisateur avec cet email.</p>";
        }
    }
}
?>
<form method="GET">
  Email : <input name="email" value="<?= htmlspecialchars($email) ?>" style="width:260px"><br><br>
  MDP   : <input name="password" value="<?= htmlspecialchars($password) ?>" style="width:200px"><br><br>
  <button>Tester</button>
</form>
