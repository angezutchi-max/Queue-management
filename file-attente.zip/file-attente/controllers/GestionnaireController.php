<?php
/**
 * controllers/GestionnaireController.php
 * Contrôleur pour l'espace Gestionnaire - Avec table utilisateurs
 */

require_once __DIR__ . '/../models/GestionnaireModel.php';
require_once __DIR__ . '/../models/UtilisateurModel.php';
require_once __DIR__ . '/../helpers/AuthHelper.php';

class GestionnaireController
{
    private GestionnaireModel $model;
    private UtilisateurModel $utilisateurModel;

    public function __construct()
    {
        $this->model = new GestionnaireModel();
        $this->utilisateurModel = new UtilisateurModel();
    }

    /* ════════════════════════════════════════════════════════
       INSCRIPTION
    ════════════════════════════════════════════════════════ */

    public function afficherInscription(): void
    {
        if (AuthHelper::estGestionnaire()) {
            header('Location: gestionnaire.php?action=dashboard');
            exit;
        }
        
        $erreurs      = [];
        $anciens      = [];
        $sousServices = $this->model->getSousServices();
        require __DIR__ . '/../views/gestionnaire/inscription.php';
    }

    public function traiterInscription(): void
    {
        $erreurs      = [];
        $sousServices = $this->model->getSousServices();

        $nom           = trim($_POST['nom']               ?? '');
        $telephone     = trim($_POST['telephone']         ?? '');
        $email         = trim($_POST['email']             ?? '');
        $password      = $_POST['password']               ?? '';
        $confirm       = $_POST['confirm']                ?? '';
        $sousServiceId = (int)($_POST['sous_service_id']  ?? 0);

        $anciens = [
            'nom'             => $nom,
            'telephone'       => $telephone,
            'email'           => $email,
            'sous_service_id' => $sousServiceId,
        ];

        if (mb_strlen($nom) < 2) {
            $erreurs['nom'] = 'Le nom doit contenir au moins 2 caractères.';
        }

        if (!preg_match('/^\+?[0-9]{8,19}$/', $telephone)) {
            $erreurs['telephone'] = 'Numéro invalide (chiffres et + uniquement).';
        } elseif ($this->model->telephoneExiste($telephone)) {
            $erreurs['telephone'] = 'Ce numéro est déjà utilisé.';
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $erreurs['email'] = 'Adresse email invalide.';
        } elseif ($this->model->emailExiste($email)) {
            $erreurs['email'] = 'Cette adresse email est déjà utilisée.';
        } elseif ($this->utilisateurModel->emailExiste($email)) {
            $erreurs['email'] = 'Cette adresse email est déjà utilisée dans le système.';
        }

        if ($sousServiceId === 0) {
            $erreurs['sous_service_id'] = 'Veuillez sélectionner un sous-service.';
        }

        if (strlen($password) < 8) {
            $erreurs['password'] = 'Minimum 8 caractères.';
        } elseif (!preg_match('/[A-Z]/', $password)) {
            $erreurs['password'] = 'Au moins une majuscule requise.';
        } elseif (!preg_match('/[0-9]/', $password)) {
            $erreurs['password'] = 'Au moins un chiffre requis.';
        }

        if ($password !== $confirm) {
            $erreurs['confirm'] = 'Les mots de passe ne correspondent pas.';
        }

        if (!empty($erreurs)) {
            require __DIR__ . '/../views/gestionnaire/inscription.php';
            return;
        }

        // 1. Créer le gestionnaire (GestionnaireModel hache lui-même avec bcrypt)
        $gestionnaireId = $this->model->creer([
            'nom'             => $nom,
            'telephone'       => $telephone,
            'email'           => $email,
            'password'        => $password,
            'sous_service_id' => $sousServiceId,
        ]);

        if (!$gestionnaireId) {
            $erreurs['global'] = 'Erreur lors de la création du compte gestionnaire.';
            require __DIR__ . '/../views/gestionnaire/inscription.php';
            return;
        }

        // 2. Créer le compte utilisateur associé (UtilisateurModel hache lui-même)
        $userId = $this->utilisateurModel->creer([
            'email'            => $email,
            'password'         => $password,
            'role'             => 'gestionnaire',
            'nom'              => $nom,
            'gestionnaire_id'  => $gestionnaireId
        ]);

        if (!$userId) {
            $erreurs['global'] = 'Erreur lors de la création du compte utilisateur.';
            require __DIR__ . '/../views/gestionnaire/inscription.php';
            return;
        }

        // 3. Connecter automatiquement
        $_SESSION['user_id'] = $userId;
        $_SESSION['user_nom'] = $nom;
        $_SESSION['user_email'] = $email;
        $_SESSION['gestionnaire_id'] = $gestionnaireId;
        $_SESSION['role'] = 'gestionnaire';
        $_SESSION['last_activity'] = time();

        // Récupérer le sous-service
        $sousService = $this->model->getSousServiceByGestionnaire($gestionnaireId);
        if ($sousService) {
            $_SESSION['sous_service_id'] = $sousService['id'];
        }

        header('Location: gestionnaire.php?action=dashboard');
        exit;
    }

    /* ════════════════════════════════════════════════════════
       CONNEXION
    ════════════════════════════════════════════════════════ */

    public function afficherConnexion(): void
    {
        if (AuthHelper::estGestionnaire()) {
            header('Location: gestionnaire.php?action=dashboard');
            exit;
        }
        
        $erreurs      = [];
        $ancien_email = '';
        require __DIR__ . '/../views/gestionnaire/connexion.php';
    }

    public function traiterConnexion(): void
    {
        $erreurs      = [];
        $ancien_email = trim($_POST['email']    ?? '');
        $password     = $_POST['password']      ?? '';

        if (empty($ancien_email) || empty($password)) {
            $erreurs['global'] = 'Veuillez remplir tous les champs.';
            require __DIR__ . '/../views/gestionnaire/connexion.php';
            return;
        }

        // Authentifier via la table utilisateurs
        $user = $this->utilisateurModel->authentifier($ancien_email, $password);

        if (!$user || $user['role'] !== 'gestionnaire') {
            $erreurs['global'] = 'Email ou mot de passe incorrect.';
            require __DIR__ . '/../views/gestionnaire/connexion.php';
            return;
        }

        // Vérifier que le gestionnaire existe
        $gestionnaire = $this->model->trouverParId($user['gestionnaire_id']);
        if (!$gestionnaire) {
            $erreurs['global'] = 'Compte gestionnaire introuvable.';
            require __DIR__ . '/../views/gestionnaire/connexion.php';
            return;
        }

        // Mettre à jour la dernière connexion
        $this->utilisateurModel->updateDerniereConnexion($user['id']);

        // Connecter
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_nom'] = $user['nom'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['gestionnaire_id'] = $user['gestionnaire_id'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['last_activity'] = time();

        // Récupérer le sous-service
        $sousService = $this->model->getSousServiceByGestionnaire($user['gestionnaire_id']);
        if ($sousService) {
            $_SESSION['sous_service_id'] = $sousService['id'];
        }

        header('Location: gestionnaire.php?action=dashboard');
        exit;
    }

    /* ════════════════════════════════════════════════════════
       DASHBOARD
    ════════════════════════════════════════════════════════ */

    public function afficherDashboard(): void
    {
        if (!AuthHelper::estGestionnaire()) {
            header('Location: gestionnaire.php?action=connexion');
            exit;
        }

        $gestionnaireId  = (int)$_SESSION['gestionnaire_id'];
        $gestionnaireNom = $_SESSION['user_nom'];

        $sousService = $this->model->getSousServiceGestionnaire($gestionnaireId);
        if (!$sousService) {
            die('Aucun sous-service affecté à ce compte. Contactez l\'administrateur.');
        }

        $ssId          = (int)$sousService['id'];
        $stats         = $this->model->statsJour($ssId);
        $file          = $this->model->fileAttente($ssId);
        $consultations = $this->model->consultationsJour($ssId);
        $urgences      = $this->model->urgencesOuvertes($ssId);
        $messageAction = '';
        $typeMessage   = 'success';
        $medecins      = $this->model->getMedecinsDisponibles($ssId);
        $horairesJour  = $this->model->getHorairesJour($ssId);

        $_SESSION['sous_service_id'] = $ssId;

        // Endpoint AJAX : chercher un patient par téléphone
        if (isset($_GET['api']) && $_GET['api'] === 'patient') {
            header('Content-Type: application/json; charset=utf-8');
            $tel    = trim($_GET['tel'] ?? '');
            $result = $tel ? $this->model->chercherPatientParTel($tel) : false;
            echo json_encode($result ?: null);
            exit;
        }

        $openQR = isset($_GET['open_qr']) ? true : false;
        require __DIR__ . '/../views/gestionnaire/dashboard.php';
    }

    /* ════════════════════════════════════════════════════════
       DÉCONNEXION
    ════════════════════════════════════════════════════════ */

    public function deconnecter(): void
    {
        session_unset();
        session_destroy();
        header('Location: accueil.php');
        exit;
    }
    
    // ═══════════════════════════════════════════════════════════════════════════════
    // MÉTHODES AJAX (traiterActionAjax, getDashboardData, getProfilData, etc.)
    // ═══════════════════════════════════════════════════════════════════════════════
    
    public function traiterActionAjax(): void
    {
        header('Content-Type: application/json');
        
        if (!AuthHelper::estGestionnaire()) {
            echo json_encode(['success' => false, 'message' => 'Non authentifié']);
            exit;
        }
        
        $action = $_POST['action'] ?? '';
        $ssId = $_SESSION['sous_service_id'] ?? null;
        
        if (!$ssId) {
            $gestionnaireId = (int)$_SESSION['gestionnaire_id'];
            $sousService = $this->model->getSousServiceGestionnaire($gestionnaireId);
            $ssId = $sousService['id'] ?? null;
            $_SESSION['sous_service_id'] = $ssId;
        }
        
        if (!$ssId) {
            echo json_encode(['success' => false, 'message' => 'Sous-service non trouvé']);
            exit;
        }
        
        // Action: Mise à jour du statut
        if ($action === 'maj_statut') {
            $cId = (int)($_POST['consultation_id'] ?? 0);
            $statut = $_POST['statut'] ?? '';
            $autorises = ['traite', 'annule', 'absent'];
            
            if ($cId > 0 && in_array($statut, $autorises, true)) {
                $this->model->majStatutConsultation($cId, $statut);
                echo json_encode(['success' => true, 'message' => 'Statut mis à jour.']);
                exit;
            }
            echo json_encode(['success' => false, 'message' => 'Action invalide.']);
            exit;
        }
        
        // Action: Consultation manuelle - sans sélection de médecin
        if ($action === 'consultation_manuelle') {
            $patNom = trim($_POST['patient_nom'] ?? '');
            $patPrenom = trim($_POST['patient_prenom'] ?? '');
            $patTel = trim($_POST['patient_telephone'] ?? '');
            $patEmail = trim($_POST['patient_email'] ?? '');
            $statut = trim($_POST['statut'] ?? 'en_attente');
            $motif = trim($_POST['motif'] ?? '');

            $errC = [];
            if (mb_strlen($patNom) < 2) $errC[] = 'Nom requis.';
            if (mb_strlen($patPrenom) < 2) $errC[] = 'Prénom requis.';
            if (!preg_match('/^\+?[0-9]{8,20}$/', $patTel)) $errC[] = 'Téléphone invalide.';

            if (empty($errC)) {
                try {
                    $patientId = $this->model->rechercherOuCreerPatient([
                        'nom' => $patNom, 
                        'prenom' => $patPrenom,
                        'telephone' => $patTel, 
                        'email' => $patEmail
                    ]);

                    $consultId = $this->model->enregistrerConsultationManuelle([
                        'patient_id' => $patientId,
                        'sous_service_id' => $ssId,
                        'mode_prise' => 'MANUEL',
                        'statut' => $statut,
                        'motif' => $motif
                    ]);

                    if ($consultId > 0) {
                        echo json_encode(['success' => true, 'message' => "Consultation enregistrée — {$patPrenom} {$patNom}."]);
                        exit;
                    } else {
                        echo json_encode(['success' => false, 'message' => 'Erreur lors de l\'enregistrement. Vérifiez les données.']);
                        exit;
                    }
                } catch (Exception $e) {
                    echo json_encode(['success' => false, 'message' => 'Erreur : ' . $e->getMessage()]);
                    exit;
                }
            } else {
                echo json_encode(['success' => false, 'message' => implode(' | ', $errC)]);
                exit;
            }
        }
        
        echo json_encode(['success' => false, 'message' => 'Action non reconnue.']);
        exit;
    }

    public function getDashboardData(): void
    {
        header('Content-Type: application/json');
        
        if (!AuthHelper::estGestionnaire()) {
            echo json_encode(['error' => 'Non authentifié']);
            exit;
        }
        
        $gestionnaireId = (int)$_SESSION['gestionnaire_id'];
        $sousService = $this->model->getSousServiceGestionnaire($gestionnaireId);
        
        if (!$sousService) {
            echo json_encode(['error' => 'Sous-service non trouvé']);
            exit;
        }
        
        $ssId = (int)$sousService['id'];
        $stats = $this->model->statsJour($ssId);
        $file = $this->model->fileAttente($ssId);
        $consultations = $this->model->consultationsJour($ssId);
        
        foreach ($file as &$c) {
            $c['heure_passage_estimee'] = $c['heure_passage_estimee'] ? date('H:i', strtotime($c['heure_passage_estimee'])) : '—';
        }
        foreach ($consultations as &$c) {
            $c['heure_passage_estimee'] = $c['heure_passage_estimee'] ? date('H:i', strtotime($c['heure_passage_estimee'])) : '—';
        }
        
        echo json_encode([
            'success' => true,
            'stats' => $stats,
            'file' => $file,
            'consultations' => $consultations
        ]);
        exit;
    }

    public function getProfilData(): void
    {
        header('Content-Type: application/json');
        
        if (!AuthHelper::estGestionnaire()) {
            echo json_encode(['success' => false, 'message' => 'Non authentifié']);
            exit;
        }

        $gestionnaireId = $_SESSION['gestionnaire_id'];
        $gestionnaire = $this->model->trouverParId($gestionnaireId);
        
        if (!$gestionnaire) {
            echo json_encode(['success' => false, 'message' => 'Utilisateur non trouvé']);
            exit;
        }

        echo json_encode([
            'success' => true,
            'profil' => [
                'nom' => $gestionnaire['nom'],
                'telephone' => $gestionnaire['telephone'],
                'email' => $gestionnaire['email']
            ]
        ]);
        exit;
    }

    public function mettreAJourProfil(): void
    {
        header('Content-Type: application/json');
        
        if (!AuthHelper::estGestionnaire()) {
            echo json_encode(['success' => false, 'message' => 'Non authentifié']);
            exit;
        }

        $id = $_SESSION['gestionnaire_id'];
        $nom = trim($_POST['nom'] ?? '');
        $telephone = trim($_POST['telephone'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $passwordActuel = $_POST['password_actuel'] ?? '';
        $nouveauPassword = $_POST['nouveau_password'] ?? '';
        $confirmerPassword = $_POST['confirmer_password'] ?? '';

        $erreurs = [];

        if (mb_strlen($nom) < 2) $erreurs['nom'] = 'Nom trop court.';
        if (!preg_match('/^\+?[0-9]{8,19}$/', $telephone)) $erreurs['telephone'] = 'Téléphone invalide.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $erreurs['email'] = 'Email invalide.';

        $gestionnaire = $this->model->trouverParId($id);
        if ($email !== $gestionnaire['email'] && $this->model->emailExiste($email)) {
            $erreurs['email'] = 'Cet email est déjà utilisé.';
        }
        if ($telephone !== $gestionnaire['telephone'] && $this->model->telephoneExiste($telephone)) {
            $erreurs['telephone'] = 'Ce numéro est déjà utilisé.';
        }

        if (!empty($nouveauPassword)) {
            if (empty($passwordActuel)) {
                $erreurs['password_actuel'] = 'Veuillez entrer votre mot de passe actuel.';
            } elseif (!$this->model->verifierMotDePasse($id, $passwordActuel)) {
                $erreurs['password_actuel'] = 'Mot de passe actuel incorrect.';
            } elseif (strlen($nouveauPassword) < 8) {
                $erreurs['nouveau_password'] = 'Minimum 8 caractères.';
            } elseif (!preg_match('/[A-Z]/', $nouveauPassword)) {
                $erreurs['nouveau_password'] = 'Au moins une majuscule.';
            } elseif (!preg_match('/[0-9]/', $nouveauPassword)) {
                $erreurs['nouveau_password'] = 'Au moins un chiffre.';
            } elseif ($nouveauPassword !== $confirmerPassword) {
                $erreurs['confirmer_password'] = 'Les mots de passe ne correspondent pas.';
            }
        }

        if (!empty($erreurs)) {
            echo json_encode(['success' => false, 'errors' => $erreurs]);
            exit;
        }

        $this->model->mettreAJourProfil($id, $nom, $telephone);
        $this->model->mettreAJourEmail($id, $email);
        
        // Mettre à jour l'email dans la table utilisateurs
        $user = $this->utilisateurModel->findByEmail($gestionnaire['email']);
        if ($user) {
            $db = Database::getInstance()->getConnection();
            $sql = "UPDATE utilisateurs SET email = :email, nom = :nom WHERE id = :id";
            $stmt = $db->prepare($sql);
            $stmt->execute([
                ':email' => $email,
                ':nom' => $nom,
                ':id' => $user['id']
            ]);
        }
        
        if (!empty($nouveauPassword)) {
            $hashedPassword = password_hash($nouveauPassword, PASSWORD_DEFAULT);
            $this->model->mettreAJourMotDePasse($id, $hashedPassword);
            // Mettre à jour le mot de passe dans la table utilisateurs
            if ($user) {
                $db = Database::getInstance()->getConnection();
                $sql = "UPDATE utilisateurs SET mot_de_passe = :password WHERE id = :id";
                $stmt = $db->prepare($sql);
                $stmt->execute([
                    ':password' => $hashedPassword,
                    ':id' => $user['id']
                ]);
            }
        }

        $_SESSION['user_nom'] = $nom;

        echo json_encode(['success' => true, 'message' => 'Profil mis à jour avec succès.']);
        exit;
    }

    public function getEmploiTemps(): void
    {
        header('Content-Type: application/json');

        if (!AuthHelper::estGestionnaire()) {
            echo json_encode(['error' => 'Non authentifié']);
            exit;
        }

        $gestionnaireId = (int)$_SESSION['gestionnaire_id'];
        $sousService    = $this->model->getSousServiceByGestionnaire($gestionnaireId);

        if (!$sousService) {
            echo json_encode(['error' => 'Sous-service non trouvé']);
            exit;
        }

        $ssId = (int)$sousService['id'];

        // Calculer lundi de la semaine demandée
        $dateParam = $_GET['date'] ?? date('Y-m-d');
        $lundiTs   = strtotime('monday this week', strtotime($dateParam));
        // Si la date passée est déjà un lundi, strtotime('monday this week') peut reculer d'une semaine — on normalise
        if (date('N', strtotime($dateParam)) == 1) {
            $lundiTs = strtotime($dateParam);
        }
        $dateDebut = date('Y-m-d', $lundiTs);
        $dateFin   = date('Y-m-d', strtotime($dateDebut . ' +6 days'));

        // ── Médecins affectés au sous-service ─────────────────────────────
        $medecins = $this->model->getMedecinsDisponibles($ssId);

        // ── Consultations de la semaine ───────────────────────────────────
        $rawConsultations = $this->model->consultationsParPeriode($ssId, $dateDebut, $dateFin);
        $consultations    = [];
        foreach ($rawConsultations as $c) {
            $consultations[] = [
                'id'              => $c['id'],
                'patient_nom'     => $c['patient_nom'],
                'patient_prenom'  => $c['patient_prenom'],
                'statut'          => $c['statut'],
                'heure_debut'     => date('H:i', strtotime($c['heure_passage_estimee'])),
                'date_consultation'=> date('Y-m-d', strtotime($c['heure_passage_estimee'])),
                'medecin_nom'     => $c['medecin_nom'] ?? 'Non assigné',
            ];
        }

        // ── Plages horaires : emplois_du_temps réels + fallback service ───
        // On récupère les créneaux enregistrés pour toute la semaine
        $plagesHoraire = [];
        foreach ($medecins as $medecin) {
            $plagesHoraire[$medecin['id']] = [];
        }

        $hasRealPlages = false;
        for ($i = 0; $i < 7; $i++) {
            $dateCourante = date('Y-m-d', strtotime($dateDebut . " +{$i} days"));
            $plages       = $this->model->getHorairesJour($ssId, $dateCourante);
            foreach ($plages as $plage) {
                $mid = $plage['medecin_id'];
                if (isset($plagesHoraire[$mid])) {
                    $plagesHoraire[$mid][] = [
                        'jour'        => $plage['jour'],
                        'heure_debut' => substr($plage['heure_debut'], 0, 5),
                        'heure_fin'   => substr($plage['heure_fin'], 0, 5),
                    ];
                    $hasRealPlages = true;
                }
            }
        }

        // ── Fallback : si aucun créneau enregistré, on utilise les horaires
        //    du service (ouverture → fermeture) comme plage virtuelle pour
        //    chaque médecin sur les jours ouvrés (lun-ven par défaut)
        if (!$hasRealPlages && !empty($medecins)) {
            $horaires       = $this->model->getServiceHoraires($ssId);
            $ouverture      = substr($horaires['horaires_ouverture'] ?? '08:00:00', 0, 5);
            $fermeture      = substr($horaires['horaires_fermeture'] ?? '18:00:00', 0, 5);
            $joursFermes    = array_filter(explode(',', $horaires['jours_fermeture'] ?? ''));
            // jours 1=lundi … 7=dimanche (ISO)
            $mapNomJour     = ['lundi'=>1,'mardi'=>2,'mercredi'=>3,'jeudi'=>4,'vendredi'=>5,'samedi'=>6,'dimanche'=>7];
            $isoClosed      = array_filter(array_map(fn($j) => $mapNomJour[trim(strtolower($j))] ?? null, $joursFermes));

            for ($i = 0; $i < 7; $i++) {
                $dateCourante = date('Y-m-d', strtotime($dateDebut . " +{$i} days"));
                $isoDay       = (int)date('N', strtotime($dateCourante));
                if (in_array($isoDay, $isoClosed, true)) continue; // jour fermé

                foreach ($medecins as $medecin) {
                    $plagesHoraire[$medecin['id']][] = [
                        'jour'        => $dateCourante,
                        'heure_debut' => $ouverture,
                        'heure_fin'   => $fermeture,
                    ];
                }
            }
        }

        echo json_encode([
            'success'       => true,
            'medecins'      => $medecins,
            'consultations' => $consultations,
            'plages_horaire'=> $plagesHoraire,
            'date_debut'    => $dateDebut,
        ]);
        exit;
    }

    public function getPlanning(): void
    {
        header('Content-Type: application/json');
        
        if (!AuthHelper::estGestionnaire()) {
            echo json_encode(['error' => 'Non authentifié']);
            exit;
        }
        
        $date = $_GET['date'] ?? date('Y-m-d');
        $sousServiceId = $_SESSION['sous_service_id'] ?? null;
        
        if (!$sousServiceId) {
            $gestionnaireId = $_SESSION['gestionnaire_id'];
            $sousService = $this->model->getSousServiceByGestionnaire($gestionnaireId);
            $sousServiceId = $sousService['id'] ?? null;
            $_SESSION['sous_service_id'] = $sousServiceId;
        }
        
        if (!$sousServiceId) {
            echo json_encode(['error' => 'Sous-service non trouvé']);
            exit;
        }
        
        $horaires = $this->model->getHorairesJour($sousServiceId, $date);
        $medecins = $this->model->getMedecinsDisponibles($sousServiceId);
        
        echo json_encode([
            'success' => true,
            'horaires' => $horaires,
            'medecins' => $medecins,
            'date' => $date
        ]);
        exit;
    }
}