<?php
require_once __DIR__ . '/config/database.php';
$db = Database::getInstance()->getConnection();

$email    = trim($_POST['email']    ?? $_GET['email']    ?? '');
$password = trim($_POST['password'] ?? $_GET['password'] ?? '');
$action   = $_POST['action'] ?? '';

echo "<style>body{font-family:monospace;padding:20px;max-width:900px} .ok{color:green} .ko{color:red} .warn{color:orange} pre{background:#f5f5f5;padding:10px;border-radius:4px}</style>";
echo "<h2>🔧 Debug3 — Test hash direct</h2>";

if ($email && $password) {

    // 1. Ce que PHP génèrerait maintenant
    $hash_default  = password_hash($password, PASSWORD_DEFAULT);
    $hash_bcrypt12 = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    $hash_bcrypt10 = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);

    echo "<h3>Hashes générés par PHP pour ce mot de passe</h3><pre>";
    echo "PASSWORD_DEFAULT (cost auto) : " . $hash_default  . "\n";
    echo "BCRYPT cost=12              : " . $hash_bcrypt12 . "\n";
    echo "BCRYPT cost=10              : " . $hash_bcrypt10 . "\n";
    echo "</pre>";

    // 2. Hash actuellement en base
    $stmt = $db->prepare("SELECT mot_de_passe FROM utilisateurs WHERE email = :e LIMIT 1");
    $stmt->execute([':e' => $email]);
    $row = $stmt->fetch();
    $hash_en_base = $row['mot_de_passe'] ?? null;

    echo "<h3>Hash en base pour cet email</h3><pre>" . htmlspecialchars($hash_en_base ?? '(aucun)') . "</pre>";

    // 3. Vérifications croisées
    echo "<h3>Vérifications</h3>";
    $tests = [
        'password_verify(mdp_clair, hash_en_base)'                         => password_verify($password, $hash_en_base ?? ''),
        'password_verify(hash_default(mdp), hash_en_base) — double-hash ?' => password_verify($hash_default, $hash_en_base ?? ''),
        'password_verify(hash_bcrypt12(mdp), hash_en_base)'                => password_verify($hash_bcrypt12, $hash_en_base ?? ''),
    ];
    foreach ($tests as $label => $result) {
        $cls = $result ? 'ok' : 'ko';
        echo "<p class='$cls'>" . ($result ? '✅' : '❌') . " $label</p>";
    }

    // 4. Reset direct si demandé
    if ($action === 'reset') {
        $newHash = password_hash($password, PASSWORD_DEFAULT);
        $stmt2   = $db->prepare("UPDATE utilisateurs SET mot_de_passe = :h WHERE email = :e");
        $ok      = $stmt2->execute([':h' => $newHash, ':e' => $email]);
        if ($ok) {
            echo "<p class='ok'>✅ Mot de passe réinitialisé en base. Essaie de te connecter maintenant.</p>";
            echo "<p>Nouveau hash : <code>" . htmlspecialchars($newHash) . "</code></p>";
        } else {
            echo "<p class='ko'>❌ Échec de la mise à jour.</p>";
        }
    }
}
?>
<hr>
<form method="POST">
  <b>Email :</b><br>
  <input name="email" value="<?= htmlspecialchars($email) ?>" style="width:300px"><br><br>
  <b>Mot de passe :</b><br>
  <input name="password" value="<?= htmlspecialchars($password) ?>" style="width:220px"><br><br>
  <button name="action" value="test">🔍 Tester seulement</button>
  &nbsp;&nbsp;
  <button name="action" value="reset"
    onclick="return confirm('Écraser le hash en base avec ce mot de passe ?')">
    🔧 Forcer reset du mot de passe en base
  </button>
</form>
<hr><small style="color:gray">⚠ Supprimer ce fichier après utilisation.</small>
