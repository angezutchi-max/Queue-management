<?php
/**
 * AdminController.php — Espace administrateur (directeur)
 * Gestion : configuration hôpital, utilisateurs, sous-services
 */

require_once __DIR__ . '/../helpers/AuthHelper.php';
require_once __DIR__ . '/../models/UtilisateurModel.php';
require_once __DIR__ . '/../models/MedecinModel.php';
require_once __DIR__ . '/../models/GestionnaireModel.php';
require_once __DIR__ . '/../models/HopitalModel.php';
require_once __DIR__ . '/../models/ServiceModel.php';

class AdminController {

    private UtilisateurModel  $utilisateurModel;
    private HopitalModel      $hopitalModel;
    private ServiceModel      $serviceModel;

    public function __construct() {
        $this->utilisateurModel = new UtilisateurModel();
        $this->hopitalModel     = new HopitalModel();
        $this->serviceModel     = new ServiceModel();
        // Garantit l'existence du service par défaut (id=1) requis par la FK sous_services
        $this->serviceModel->creerServiceParDefaut();
    }

    // ══════════════════════════════════════════════════════
    //  Dashboard
    // ══════════════════════════════════════════════════════

    public function afficherDashboard(): void {
        AuthHelper::exigerRole('admin');

        $hopital       = $this->hopitalModel->getData();
        $gestionnaires = $this->utilisateurModel->listerParRole('gestionnaire');
        $medecins      = $this->utilisateurModel->listerParRole('medecin');
        $sousServices  = $this->serviceModel->getSousServicesParService(1);
        $setupDone     = isset($_GET['setup']);
        $nouveauUser   = $_SESSION['nouveau_utilisateur'] ?? null;
        unset($_SESSION['nouveau_utilisateur']);

        include __DIR__ . '/../views/admin/dashboard.php';
    }

    // ══════════════════════════════════════════════════════
    //  Configuration hôpital
    // ══════════════════════════════════════════════════════

    public function sauvegarderHopital(): void {
        AuthHelper::exigerRole('admin');
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: admin.php'); exit; }

        $data = [
            'nom_hopital' => trim($_POST['nom_hopital'] ?? ''),
            'adresse'     => trim($_POST['adresse']     ?? ''),
            'telephone'   => trim($_POST['telephone']   ?? ''),
            'email'       => trim($_POST['email']       ?? ''),
            'logo_path'   => null,
        ];

        if (empty($data['nom_hopital'])) {
            header('Location: admin.php?tab=hopital&error=nom_hopital_requis'); exit;
        }

        if (!empty($_FILES['logo']['tmp_name'])) {
            $ext     = strtolower(pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'svg', 'webp'];
            if (in_array($ext, $allowed, true)) {
                $destDir = __DIR__ . '/../public/uploads/hopital/';
                if (!is_dir($destDir)) mkdir($destDir, 0755, true);
                $filename = 'logo_' . time() . '.' . $ext;
                if (move_uploaded_file($_FILES['logo']['tmp_name'], $destDir . $filename)) {
                    $data['logo_path'] = 'public/uploads/hopital/' . $filename;
                }
            }
        } else {
            $existing        = $this->hopitalModel->getData();
            $data['logo_path'] = $existing['logo_path'] ?? null;
        }

        $ok = $this->hopitalModel->sauvegarder($data);
        header('Location: admin.php?tab=hopital&' . ($ok ? 'success=hopital_sauvegarde' : 'error=sauvegarde_echouee'));
        exit;
    }

    // ══════════════════════════════════════════════════════
    //  Utilisateurs  (médecin / gestionnaire)
    // ══════════════════════════════════════════════════════

    /**
     * Affiche le formulaire de création via views/admin/creer_utilisateur.php
     * URL : admin.php?action=creer_utilisateur&role=medecin|gestionnaire  (GET)
     */
    public function afficherFormulaireUtilisateur(): void {
        AuthHelper::exigerRole('admin');

        $role        = in_array($_GET['role'] ?? '', ['medecin', 'gestionnaire'], true)
                       ? $_GET['role']
                       : 'gestionnaire';
        $sousServices = $this->serviceModel->getSousServicesParService(1);

        // Erreurs et anciennes valeurs transmises via session (PRG pattern)
        $erreurs = $_SESSION['creer_erreurs'] ?? [];
        $anciens = $_SESSION['creer_anciens'] ?? [];
        unset($_SESSION['creer_erreurs'], $_SESSION['creer_anciens']);

        include __DIR__ . '/../views/admin/creer_utilisateur.php';
    }

    /**
     * Traite la soumission du formulaire
     * URL : admin.php?action=creer_utilisateur  (POST)
     */
    public function creerUtilisateur(): void {
        AuthHelper::exigerRole('admin');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: admin.php');
            exit;
        }

        $role          = $_POST['role']          ?? '';
        $nom           = trim($_POST['nom']       ?? '');
        $prenom        = trim($_POST['prenom']    ?? '');   // médecin uniquement
        $email         = strtolower(trim($_POST['email']    ?? ''));
        $telephone     = trim($_POST['telephone'] ?? '');
        $specialite    = trim($_POST['specialite'] ?? '');  // médecin uniquement
        $sousServiceId = (int) ($_POST['sous_service_id'] ?? 0);
        $password      = $_POST['password']       ?? '';
        $confirm       = $_POST['confirm']        ?? '';

        $tab = $role === 'medecin' ? 'medecins' : 'gestionnaires';

        // ── Validation ────────────────────────────────────────
        $erreurs = [];

        if (!in_array($role, ['gestionnaire', 'medecin'], true)) {
            header('Location: admin.php?tab=' . $tab . '&error=role_invalide');
            exit;
        }

        if (empty($nom)) {
            $erreurs['nom'] = 'Le nom est requis.';
        }
        if ($role === 'medecin' && empty($prenom)) {
            $erreurs['prenom'] = 'Le prénom est requis.';
        }
        if (empty($email)) {
            $erreurs['email'] = "L'email est requis.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $erreurs['email'] = "L'email est invalide.";
        } elseif ($this->utilisateurModel->emailExiste($email)) {
            $erreurs['email'] = 'Cette adresse email est déjà utilisée.';
        }
        if (empty($telephone)) {
            $erreurs['telephone'] = 'Le téléphone est requis.';
        }
        if ($role === 'medecin' && empty($specialite)) {
            $erreurs['specialite'] = 'La spécialité est requise.';
        }
        if ($role === 'gestionnaire' && $sousServiceId <= 0) {
            $erreurs['sous_service_id'] = 'Veuillez sélectionner un sous-service.';
        }
        if (strlen($password) < 8) {
            $erreurs['password'] = 'Le mot de passe doit contenir au moins 8 caractères.';
        }
        if ($password !== $confirm) {
            $erreurs['confirm'] = 'Les mots de passe ne correspondent pas.';
        }

        if (!empty($erreurs)) {
            $_SESSION['creer_erreurs'] = $erreurs;
            $_SESSION['creer_anciens'] = [
                'nom'            => $nom,
                'prenom'         => $prenom,
                'email'          => $email,
                'telephone'      => $telephone,
                'specialite'     => $specialite,
                'sousServiceId'  => $sousServiceId,
            ];
            header('Location: admin.php?action=creer_utilisateur&role=' . $role);
            exit;
        }

        // ── Insertion dans la table métier + utilisateurs ─────
        if ($role === 'medecin') {
            $this->_creerMedecin($nom, $prenom, $specialite, $email, $telephone, $password);
        } else {
            $this->_creerGestionnaire($nom, $email, $telephone, $password, $sousServiceId);
        }
    }

    // ── Helpers privés ────────────────────────────────────────────────────

    private function _creerMedecin(
        string $nom,
        string $prenom,
        string $specialite,
        string $email,
        string $telephone,
        string $password
    ): void {
        $medecinModel = new MedecinModel();

        $ok = $medecinModel->creer([
            'nom'        => $nom,
            'prenom'     => $prenom,
            'specialite' => $specialite,
            'email'      => $email,
            'telephone'  => $telephone,
            'password'   => $password,
        ]);

        if (!$ok) {
            header('Location: admin.php?tab=medecins&error=creation_echouee');
            exit;
        }

        $medecinId = $medecinModel->dernierID();

        // Crée le compte utilisateur lié
        $userId = $this->utilisateurModel->creer([
            'email'      => $email,
            'password'   => $password,
            'nom'        => $prenom . ' ' . $nom,
            'role'       => 'medecin',
            'medecin_id' => $medecinId,
        ]);

        if (!$userId) {
            header('Location: admin.php?tab=medecins&error=creation_echouee');
            exit;
        }

        $_SESSION['nouveau_utilisateur'] = [
            'nom'            => $prenom . ' ' . $nom,
            'email'          => $email,
            'role'           => 'medecin',
            'password_clair' => $password,
        ];

        header('Location: admin.php?tab=medecins&success=utilisateur_cree');
        exit;
    }

    private function _creerGestionnaire(
        string $nom,
        string $email,
        string $telephone,
        string $password,
        int    $sousServiceId
    ): void {
        $gestionnaireModel = new GestionnaireModel();

        $ok = $gestionnaireModel->creer([
            'nom'            => $nom,
            'email'          => $email,
            'telephone'      => $telephone,
            'password'       => $password,
            'sous_service_id'=> $sousServiceId,
        ]);

        if (!$ok) {
            header('Location: admin.php?tab=gestionnaires&error=creation_echouee');
            exit;
        }

        $gestionnaireId = $gestionnaireModel->dernierID();

        // Crée le compte utilisateur lié
        $userId = $this->utilisateurModel->creer([
            'email'           => $email,
            'password'        => $password,
            'nom'             => $nom,
            'role'            => 'gestionnaire',
            'gestionnaire_id' => $gestionnaireId,
        ]);

        if (!$userId) {
            header('Location: admin.php?tab=gestionnaires&error=creation_echouee');
            exit;
        }

        $_SESSION['nouveau_utilisateur'] = [
            'nom'            => $nom,
            'email'          => $email,
            'role'           => 'gestionnaire',
            'password_clair' => $password,
        ];

        header('Location: admin.php?tab=gestionnaires&success=utilisateur_cree');
        exit;
    }

    // ══════════════════════════════════════════════════════
    //  Toggle statut utilisateur
    // ══════════════════════════════════════════════════════

    public function toggleStatutUtilisateur(): void {
        AuthHelper::exigerRole('admin');
        $id     = (int) ($_POST['user_id'] ?? 0);
        $statut = ($_POST['statut'] ?? '') === 'actif' ? 'actif' : 'inactif';
        $tab    = $_POST['tab'] ?? 'gestionnaires';
        if (!$id) { header('Location: admin.php?error=id_invalide'); exit; }
        $this->utilisateurModel->mettreAJourStatut($id, $statut);
        header('Location: admin.php?tab=' . $tab . '&success=statut_mis_a_jour');
        exit;
    }

    // ══════════════════════════════════════════════════════
    //  Sous-services CRUD
    // ══════════════════════════════════════════════════════

    public function creerSousService(): void {
        AuthHelper::exigerRole('admin');
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: admin.php?tab=sous_services'); exit; }

        $nom         = trim($_POST['nom']          ?? '');
        $description = trim($_POST['description']  ?? '');
        $duree       = max(300, (int) ($_POST['duree_rdv_defaut'] ?? 1800));
        $capacite    = max(1,   (int) ($_POST['capacite_horaire'] ?? 10));

        if (empty($nom)) {
            header('Location: admin.php?tab=sous_services&error=ss_nom_requis'); exit;
        }
        if ($this->serviceModel->nomSsExiste($nom, 1)) {
            header('Location: admin.php?tab=sous_services&error=ss_nom_existe'); exit;
        }

        $ok = $this->serviceModel->creerSousService([
            'service_id'       => 1,
            'nom'              => $nom,
            'description'      => $description,
            'duree_rdv_defaut' => $duree,
            'capacite_horaire' => $capacite,
        ]);

        header('Location: admin.php?tab=sous_services&' . ($ok ? 'success=ss_cree' : 'error=ss_echec'));
        exit;
    }

    public function modifierSousService(): void {
        AuthHelper::exigerRole('admin');
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: admin.php?tab=sous_services'); exit; }

        $id          = (int) ($_POST['ss_id']           ?? 0);
        $nom         = trim($_POST['nom']               ?? '');
        $description = trim($_POST['description']       ?? '');
        $duree       = max(300, (int) ($_POST['duree_rdv_defaut'] ?? 1800));
        $capacite    = max(1,   (int) ($_POST['capacite_horaire'] ?? 10));
        $statut      = in_array($_POST['statut'] ?? '', ['actif', 'inactif']) ? $_POST['statut'] : 'actif';

        if (!$id || empty($nom)) {
            header('Location: admin.php?tab=sous_services&error=ss_donnees_invalides'); exit;
        }
        if ($this->serviceModel->nomSsExiste($nom, 1, $id)) {
            header('Location: admin.php?tab=sous_services&error=ss_nom_existe'); exit;
        }

        $ok = $this->serviceModel->modifierSousService($id, [
            'nom'              => $nom,
            'description'      => $description,
            'duree_rdv_defaut' => $duree,
            'capacite_horaire' => $capacite,
            'statut'           => $statut,
        ]);

        header('Location: admin.php?tab=sous_services&' . ($ok ? 'success=ss_modifie' : 'error=ss_echec'));
        exit;
    }

    public function supprimerSousService(): void {
        AuthHelper::exigerRole('admin');
        $id = (int) ($_POST['ss_id'] ?? 0);
        if (!$id) { header('Location: admin.php?tab=sous_services&error=id_invalide'); exit; }

        $result = $this->serviceModel->supprimerSousService($id);
        if ($result['ok']) {
            header('Location: admin.php?tab=sous_services&success=ss_supprime');
        } else {
            $_SESSION['ss_error_msg'] = $result['msg'];
            header('Location: admin.php?tab=sous_services&error=ss_suppression_impossible');
        }
        exit;
    }

    public function toggleStatutSousService(): void {
        AuthHelper::exigerRole('admin');
        $id = (int) ($_POST['ss_id'] ?? 0);
        if (!$id) { header('Location: admin.php?tab=sous_services&error=id_invalide'); exit; }
        $this->serviceModel->basculerStatutSs($id);
        header('Location: admin.php?tab=sous_services&success=ss_statut_maj');
        exit;
    }
}