<?php
/**
 * models/GestionnaireModel.php
 * Modèle MVC — Gestionnaire
 * Adapté à la base files_attente v3 :
 *   - Table : consultations  (plus rendez_vous)
 *   - sous_service_id directement dans gestionnaires (plus de table pivot)
 *   - gestionnaires contient : nom, telephone, email, password, sous_service_id
 */
require_once __DIR__ . '/../config/database.php';

class GestionnaireModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    /* ════════════════════════════════════════════════════════
       AUTHENTIFICATION & COMPTE
    ════════════════════════════════════════════════════════ */

    /** Vérifie si l'email existe déjà */
    public function emailExiste(string $email): bool
    {
        $stmt = $this->db->prepare(
            'SELECT COUNT(*) FROM gestionnaires WHERE email = :e'
        );
        $stmt->execute([':e' => strtolower(trim($email))]);
        return (int)$stmt->fetchColumn() > 0;
    }

    /** Vérifie si le téléphone existe déjà */
    public function telephoneExiste(string $telephone): bool
    {
        $stmt = $this->db->prepare(
            'SELECT COUNT(*) FROM gestionnaires WHERE telephone = :t'
        );
        $stmt->execute([':t' => trim($telephone)]);
        return (int)$stmt->fetchColumn() > 0;
    }

    /**
     * Crée un gestionnaire
     * Colonnes : nom, telephone, email, password, sous_service_id
     */
    public function creer(array $d): bool
    {
        $stmt = $this->db->prepare(
            'INSERT INTO gestionnaires (nom, telephone, email, password, sous_service_id)
             VALUES (:nom, :telephone, :email, :password, :sous_service_id)'
        );
        return $stmt->execute([
            ':nom'             => htmlspecialchars(trim($d['nom'])),
            ':telephone'       => trim($d['telephone']),
            ':email'           => strtolower(trim($d['email'])),
            ':password'        => password_hash($d['password'], PASSWORD_BCRYPT, ['cost' => 12]),
            ':sous_service_id' => (int)$d['sous_service_id'],
        ]);
    }

    /** Trouve un gestionnaire par email (pour la connexion) */
    public function trouverParEmail(string $email)
    {
        $stmt = $this->db->prepare(
            'SELECT * FROM gestionnaires WHERE email = :e LIMIT 1'
        );
        $stmt->execute([':e' => strtolower(trim($email))]);
        return $stmt->fetch();
    }

    /** Trouve un gestionnaire par ID */
    public function trouverParId(int $id)
    {
        $stmt = $this->db->prepare(
            'SELECT id, nom, telephone, email, sous_service_id
             FROM gestionnaires WHERE id = :id'
        );
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    /** Retourne le dernier ID inséré */
    public function dernierID(): int
    {
        return (int)$this->db->lastInsertId();
    }

    /* ════════════════════════════════════════════════════════
       SOUS-SERVICES (pour le select d'inscription)
    ════════════════════════════════════════════════════════ */

    /**
     * Liste tous les sous-services actifs avec leur hôpital
     * Créés par le médecin chef de service
     */
    public function getSousServices(): array
    {
        $stmt = $this->db->query(
            'SELECT ss.id, ss.nom, s.nom AS service_nom
             FROM sous_services ss
             JOIN services s ON s.id = ss.service_id
             WHERE ss.statut = "actif"
               AND s.statut  = "actif"
             ORDER BY s.nom, ss.nom'
        );
        return $stmt->fetchAll();
    }

    /**
     * Sous-service affecté à ce gestionnaire
     * sous_service_id est directement dans la table gestionnaires
     */
    public function getSousServiceGestionnaire(int $gestionnaireId)
    {
        $stmt = $this->db->prepare(
            'SELECT ss.id, ss.nom, ss.duree_estimee,
                    ss.capacite_horaire, ss.qr_code,
                    s.nom AS service_nom, s.adresse AS service_adresse
             FROM gestionnaires g
             JOIN sous_services ss ON ss.id = g.sous_service_id
             JOIN services      s  ON s.id  = ss.service_id
             WHERE g.id = :gid
             LIMIT 1'
        );
        $stmt->execute([':gid' => $gestionnaireId]);
        return $stmt->fetch();
    }

    /* ════════════════════════════════════════════════════════
       DASHBOARD — STATISTIQUES DU JOUR
    ════════════════════════════════════════════════════════ */

    /** Statistiques du jour pour un sous-service */
    public function statsJour(int $ssId): array
    {
        $stmt = $this->db->prepare(
            'SELECT
               COUNT(*)                                          AS total,
               SUM(statut = "traite")                           AS traitees,
               SUM(statut IN ("en_attente", "confirme"))        AS en_attente,
               SUM(statut = "absent")                           AS absentes,
               SUM(statut = "annule")                           AS annulees,
               SUM(mode_prise = "LIGNE")                        AS en_ligne,
               SUM(mode_prise = "PLACE")                        AS sur_place
             FROM consultations
             WHERE sous_service_id = :ss
               AND DATE(heure_emission) = CURDATE()'
        );
        $stmt->execute([':ss' => $ssId]);
        return $stmt->fetch() ?: [];
    }

    /* ════════════════════════════════════════════════════════
       DASHBOARD — FILE D'ATTENTE
    ════════════════════════════════════════════════════════ */

    /** File d'attente en cours (statuts actifs uniquement) */
    public function fileAttente(int $ssId): array
    {
        $stmt = $this->db->prepare(
            'SELECT
               c.id, c.rang, c.statut, c.mode_prise,
               c.heure_passage_estimee, c.motif,
               p.nom AS patient_nom, p.prenom AS patient_prenom,
               p.telephone,
               CONCAT(m.prenom, " ", m.nom) AS medecin_nom
             FROM consultations c
             JOIN patients p ON p.id = c.patient_id
             LEFT JOIN medecins m ON m.id = c.medecin_id
             WHERE c.sous_service_id = :ss
               AND c.statut IN ("en_attente", "confirme", "en_cours")
               AND DATE(c.heure_emission) = CURDATE()
             ORDER BY c.rang'
        );
        $stmt->execute([':ss' => $ssId]);
        return $stmt->fetchAll();
    }

    /** Toutes les consultations du jour */
    public function consultationsJour(int $ssId): array
    {
        $stmt = $this->db->prepare(
            'SELECT
               c.id, c.rang, c.statut, c.mode_prise,
               c.heure_passage_estimee,
               c.heure_debut_reelle, c.heure_fin_reelle,
               c.motif,
               p.nom AS patient_nom, p.prenom AS patient_prenom,
               p.telephone,
               CONCAT(m.prenom, " ", m.nom) AS medecin_nom
             FROM consultations c
             JOIN patients p ON p.id = c.patient_id
             LEFT JOIN medecins m ON m.id = c.medecin_id
             WHERE c.sous_service_id = :ss
               AND DATE(c.heure_emission) = CURDATE()
             ORDER BY c.rang'
        );
        $stmt->execute([':ss' => $ssId]);
        return $stmt->fetchAll();
    }

    /* ════════════════════════════════════════════════════════
       DASHBOARD — ACTIONS GESTIONNAIRE
    ════════════════════════════════════════════════════════ */

    /** Mettre à jour le statut d'une consultation */
    public function majStatutConsultation(int $consultationId, string $statut): bool
    {
        $stmt = $this->db->prepare(
            'UPDATE consultations SET statut = :s WHERE id = :id'
        );
        return $stmt->execute([':s' => $statut, ':id' => $consultationId]);
    }

    /**
     * Appeler le patient suivant en attente
     * Passe son statut à "en_cours"
     */
    public function appelerSuivant(int $ssId)
    {
        $stmt = $this->db->prepare(
            'SELECT c.id, c.rang, p.nom, p.prenom, p.telephone
             FROM consultations c
             JOIN patients p ON p.id = c.patient_id
             WHERE c.sous_service_id = :ss
               AND c.statut = "en_attente"
               AND DATE(c.heure_emission) = CURDATE()
             ORDER BY c.rang
             LIMIT 1'
        );
        $stmt->execute([':ss' => $ssId]);
        $suivant = $stmt->fetch();
        if ($suivant) {
            $this->majStatutConsultation($suivant['id'], 'en_cours');
        }
        return $suivant;
    }

    /* ════════════════════════════════════════════════════════
       DASHBOARD — URGENCES
    ════════════════════════════════════════════════════════ */

    /** Urgences ouvertes du service lié au sous-service */
    public function urgencesOuvertes(int $ssId): array
    {
        $stmt = $this->db->prepare(
            'SELECT u.id, u.description, u.priorite, u.statut, u.created_at
             FROM urgences u
             JOIN sous_services ss ON ss.service_id = u.service_id
             WHERE ss.id = :ss
               AND u.statut != "cloturee"
             ORDER BY u.priorite ASC, u.created_at DESC'
        );
        $stmt->execute([':ss' => $ssId]);
        return $stmt->fetchAll();
    }

    /* ════════════════════════════════════════════════════════
       CONSULTATION MANUELLE
    ════════════════════════════════════════════════════════ */

    /**
     * Cherche un patient par téléphone ou email.
     * Si absent, le crée avec les données fournies.
     * Retourne l'ID du patient.
     */
    public function rechercherOuCreerPatient(array $d): int
    {
        $telephone = trim($d['telephone']);
        $email     = trim($d['email']);
        $nom       = htmlspecialchars(trim($d['nom']));
        $prenom    = htmlspecialchars(trim($d['prenom']));

        // Chercher par téléphone d'abord
        $stmt = $this->db->prepare(
            'SELECT id FROM patients WHERE telephone = :tel LIMIT 1'
        );
        $stmt->execute([':tel' => $telephone]);
        $row = $stmt->fetch();
        if ($row) return (int)$row['id'];

        // Chercher par email si fourni
        if (!empty($email)) {
            $stmt = $this->db->prepare(
                'SELECT id FROM patients WHERE email = :email LIMIT 1'
            );
            $stmt->execute([':email' => $email]);
            $row = $stmt->fetch();
            if ($row) return (int)$row['id'];
        }

        // Créer le patient (email unique : si vide on génère un placeholder)
        $emailFinal = !empty($email) ? $email : $telephone . '@noemail.local';
        $stmt = $this->db->prepare(
            'INSERT INTO patients (nom, prenom, telephone, email, statut)
             VALUES (:nom, :prenom, :tel, :email, "actif")'
        );
        $stmt->execute([
            ':nom'    => $nom,
            ':prenom' => $prenom,
            ':tel'    => $telephone,
            ':email'  => $emailFinal,
        ]);
        return (int)$this->db->lastInsertId();
    }

    /**
     * Retourne le prochain rang disponible dans la file du jour
     * pour ce sous-service.
     */
    public function prochainRang(int $ssId): int
    {
        $stmt = $this->db->prepare(
            'SELECT COALESCE(MAX(rang), 0) + 1
             FROM consultations
             WHERE sous_service_id = :ss
               AND DATE(heure_emission) = CURDATE()'
        );
        $stmt->execute([':ss' => $ssId]);
        return (int)$stmt->fetchColumn();
    }

    /**
     * MODE PLACE (gestionnaire) / QR / LIGNE :
     * Enregistre une consultation avec sélection automatique du médecin
     * le moins occupé et calcul d'heure basé sur planning + heure courante.
     */
    public function enregistrerConsultationManuelle(array $d): int
    {
        $ssId      = (int)$d['sous_service_id'];
        $modePrise = in_array($d['mode_prise'] ?? '', ['LIGNE','PLACE','QR'])
                     ? $d['mode_prise'] : 'PLACE';
        $statut    = in_array($d['statut'] ?? '', ['en_attente','confirme'])
                     ? $d['statut'] : 'en_attente';

        // 1. Médecin : si non précisé → choisir le moins occupé
        $medecinId = !empty($d['medecin_id']) ? (int)$d['medecin_id'] : null;
        if (!$medecinId) {
            $medecinId = $this->choisirMedecinMoinsOccupe($ssId) ?: null;
        }

        // 2. Rang dans la file du jour
        $rang = $this->prochainRang($ssId);

        // 3. Durée estimée de la consultation
        $dureeEstimee = $this->getDureeEstimee($ssId);

        // 4. Heure de début et fin estimées (planning + file d'attente)
        $heures = $this->calculerHeuresEstimees($ssId, $medecinId, $rang, $dureeEstimee);

        // QR = prise sur place via scan → stocké comme PLACE dans l'enum
        $modePriseDB = ($modePrise === 'QR') ? 'PLACE' : $modePrise;

        $stmt = $this->db->prepare(
            'INSERT INTO consultations
               (patient_id, sous_service_id, medecin_id,
                statut, rang, mode_prise,
                heure_emission, heure_passage_estimee,
                duree_estimee, motif)
             VALUES
               (:patient_id, :ss_id, :medecin_id,
                :statut, :rang, :mode_prise,
                NOW(), :heure_debut,
                :duree_estimee, :motif)'
        );
        $ok = $stmt->execute([
            ':patient_id'    => (int)$d['patient_id'],
            ':ss_id'         => $ssId,
            ':medecin_id'    => $medecinId,
            ':statut'        => $statut,
            ':rang'          => $rang,
            ':mode_prise'    => $modePriseDB,
            ':heure_debut'   => $heures['debut'],
            ':duree_estimee' => $dureeEstimee,
            ':motif'         => !empty($d['motif'])
                                  ? htmlspecialchars(trim($d['motif'])) : null,
        ]);
        return $ok ? (int)$this->db->lastInsertId() : 0;
    }

    /**
     * Sélectionne le médecin le moins occupé du sous-service aujourd'hui.
     * Tri par : nb consultations actives ASC, heure début planning ASC.
     */
    public function choisirMedecinMoinsOccupe(int $ssId): int
    {
        $stmt = $this->db->prepare(
            'SELECT m.id,
                    COALESCE(occ.nb, 0)                     AS nb_consultations,
                    COALESCE(edt.heure_debut, "23:59:59")   AS heure_debut_planning
             FROM medecins m
             JOIN medecin_sous_service mss ON mss.medecin_id = m.id
             LEFT JOIN (
                 SELECT medecin_id, COUNT(*) AS nb
                 FROM consultations
                 WHERE sous_service_id = :ss1
                   AND DATE(heure_emission) = CURDATE()
                   AND statut IN ("en_attente","confirme","en_cours")
                 GROUP BY medecin_id
             ) occ ON occ.medecin_id = m.id
             LEFT JOIN (
                 SELECT medecin_id, MIN(heure_debut) AS heure_debut
                 FROM emplois_du_temps
                 WHERE sous_service_id = :ss2
                   AND jour = CURDATE()
                 GROUP BY medecin_id
             ) edt ON edt.medecin_id = m.id
             WHERE mss.sous_service_id = :ss3
               AND m.statut = "disponible"
             ORDER BY nb_consultations ASC, heure_debut_planning ASC
             LIMIT 1'
        );
        $stmt->execute([
            ':ss1' => $ssId,
            ':ss2' => $ssId,
            ':ss3' => $ssId,
        ]);
        $row = $stmt->fetch();
        return $row ? (int)$row['id'] : 0;
    }

    /** Durée estimée (en secondes) configurée pour le sous-service */
    private function getDureeEstimee(int $ssId): int
    {
        $stmt = $this->db->prepare(
            'SELECT COALESCE(duree_estimee, duree_rdv_defaut, 1800)
             FROM sous_services WHERE id = :id'
        );
        $stmt->execute([':id' => $ssId]);
        return (int)($stmt->fetchColumn() ?: 1800);
    }

    /**
     * Calcule heure_debut et heure_fin estimées pour une consultation.
     *
     * Algorithme :
     *  base = MAX(heure_debut_planning_medecin_aujourd'hui, maintenant)
     *  offset = nombre de consultations actives AVANT ce rang × duree_estimee
     *  heure_debut = base + offset
     *  heure_fin   = heure_debut + duree_estimee
     *
     * @return array ['debut' => string, 'fin' => string]
     */
    private function calculerHeuresEstimees(int $ssId, ?int $medecinId, int $rang, int $duree): array
    {
        $maintenant = time();
        $base       = $maintenant;

        // Heure de début du planning du médecin aujourd'hui
        if ($medecinId) {
            $stmt = $this->db->prepare(
                'SELECT MIN(heure_debut)
                 FROM emplois_du_temps
                 WHERE sous_service_id = :ss
                   AND medecin_id      = :mid
                   AND jour            = CURDATE()'
            );
            $stmt->execute([':ss' => $ssId, ':mid' => $medecinId]);
            $hdp = $stmt->fetchColumn();
            if ($hdp) {
                $tsPlanning = strtotime(date('Y-m-d') . ' ' . $hdp);
                // Si le médecin n'a pas encore commencé → attendre son arrivée
                $base = max($tsPlanning, $maintenant);
            }
        }

        // Consultations actives AVANT ce rang pour ce médecin (ou tout le SS si sans médecin)
        if ($medecinId) {
            $stmt = $this->db->prepare(
                'SELECT COUNT(*) FROM consultations
                 WHERE sous_service_id = :ss
                   AND medecin_id      = :mid
                   AND DATE(heure_emission) = CURDATE()
                   AND statut IN ("en_attente","confirme","en_cours")
                   AND rang < :rang'
            );
            $stmt->execute([':ss' => $ssId, ':mid' => $medecinId, ':rang' => $rang]);
        } else {
            $stmt = $this->db->prepare(
                'SELECT COUNT(*) FROM consultations
                 WHERE sous_service_id = :ss
                   AND DATE(heure_emission) = CURDATE()
                   AND statut IN ("en_attente","confirme","en_cours")
                   AND rang < :rang'
            );
            $stmt->execute([':ss' => $ssId, ':rang' => $rang]);
        }
        $nbAvant = (int)$stmt->fetchColumn();

        $tsDebut = $base + ($nbAvant * $duree);
        $tsFin   = $tsDebut + $duree;

        return [
            'debut' => date('Y-m-d H:i:s', $tsDebut),
            'fin'   => date('Y-m-d H:i:s', $tsFin),
        ];
    }

    /** Médecins disponibles affectés à un sous-service avec leur charge du jour */
    public function getMedecinsDisponibles(int $ssId): array
    {
        $stmt = $this->db->prepare(
            'SELECT m.id, m.nom, m.prenom, m.specialite, m.statut,
                    COALESCE(occ.nb, 0) AS nb_en_attente
             FROM medecins m
             JOIN medecin_sous_service mss ON mss.medecin_id = m.id
             LEFT JOIN (
                 SELECT medecin_id, COUNT(*) AS nb
                 FROM consultations
                 WHERE sous_service_id = :ss2
                   AND DATE(heure_emission) = CURDATE()
                   AND statut IN ("en_attente","confirme","en_cours")
                 GROUP BY medecin_id
             ) occ ON occ.medecin_id = m.id
             WHERE mss.sous_service_id = :ss
               AND m.statut = "disponible"
             ORDER BY occ.nb ASC, m.nom'
        );
        $stmt->execute([':ss' => $ssId, ':ss2' => $ssId]);
        return $stmt->fetchAll();
    }

    /** Cherche un patient par téléphone (pour auto-remplissage AJAX) */
    public function chercherPatientParTel(string $telephone)
    {
        $stmt = $this->db->prepare(
            'SELECT id, nom, prenom, telephone, email
             FROM patients
             WHERE telephone = :tel LIMIT 1'
        );
        $stmt->execute([':tel' => $telephone]);
        return $stmt->fetch();
    }
}
