<?php
/**
 * gestionnaire.php — Point d'entrée espace gestionnaire
 * Routeur principal pour toutes les actions des gestionnaires
 *
 * ACCÈS : UNIQUEMENT les gestionnaires (ni médecin, ni admin)
 */

require_once __DIR__ . '/helpers/AuthHelper.php';

// L'inscription et la connexion sont publiques : pas de vérification d'accès
$action = $_GET['action'] ?? 'dashboard';

if (!in_array($action, ['inscription', 'connexion'])) {
    if (!AuthHelper::estGestionnaire()) {
        header('Location: accueil.php');
        exit;
    }
    AuthHelper::verifierSession('gestionnaire.php?action=connexion');
}

// Configuration
error_reporting(E_ALL);
ini_set('display_errors', 1);

$allowedActions = [
    // Authentification
    'inscription', 'connexion', 'dashboard', 'deconnexion',
    // QR Code
    'generer_qrcode', 'get_qrcode_actif', 'telecharger_qrcode',
    // Planning
    'get_planning', 'get_emploi_temps',
    // Actions AJAX
    'get_dashboard_data', 'traiter_action_ajax',
    // Profil
    'get_profil_data', 'mettre_a_jour_profil'
];

if (!in_array($action, $allowedActions)) {
    http_response_code(404);
    die('Page introuvable.');
}

require_once __DIR__ . '/controllers/GestionnaireController.php';
$ctrl = new GestionnaireController();

// QRCodeController chargé uniquement pour les actions QR (évite les warnings phpqrcode)
$qrActions = ['generer_qrcode', 'get_qrcode_actif', 'telecharger_qrcode'];
if (in_array($action, $qrActions)) {
    require_once __DIR__ . '/controllers/QRCodeController.php';
    $qrCtrl = new QRCodeController();
}

switch ($action) {
    case 'inscription':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $ctrl->traiterInscription();
        } else {
            $ctrl->afficherInscription();
        }
        break;

    case 'connexion':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $ctrl->traiterConnexion();
        } else {
            $ctrl->afficherConnexion();
        }
        break;

    case 'dashboard':
        $ctrl->afficherDashboard();
        break;

    case 'deconnexion':
        $ctrl->deconnecter();
        break;

    case 'generer_qrcode':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $qrCtrl->genererQRCode();
        } else {
            $qrCtrl->afficherGenerateur();
        }
        break;

    case 'get_qrcode_actif':
        $qrCtrl->getQRCodeActif();
        break;

    case 'telecharger_qrcode':
        $qrCtrl->telechargerQRCode();
        break;

    case 'get_planning':
        $ctrl->getPlanning();
        break;

    case 'get_emploi_temps':
        $ctrl->getEmploiTemps();
        break;

    case 'get_dashboard_data':
        $ctrl->getDashboardData();
        break;

    case 'traiter_action_ajax':
        $ctrl->traiterActionAjax();
        break;

    case 'get_profil_data':
        $ctrl->getProfilData();
        break;

    case 'mettre_a_jour_profil':
        $ctrl->mettreAJourProfil();
        break;

    default:
        $ctrl->afficherDashboard();
        break;
}