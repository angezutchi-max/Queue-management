<?php
/**
 * models/MedecinModel.php
 * Modèle MVC — Médecin (Version mono-service)
 */

require_once __DIR__ . '/../config/database.php';

class MedecinModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    /* ════════════════════════════════════════════════════════
       AUTHENTIFICATION & COMPTE (plus de service_id)
    ════════════════════════════════════════════════════════ */

    public function emailExiste(string $email): bool
    {
        $stmt = $this->db->prepare('SELECT COUNT(*) FROM medecins WHERE email = :e');
        $stmt->execute([':e' => strtolower(trim($email))]);
        return (int)$stmt->fetchColumn() > 0;
    }

    public function telephoneExiste(string $tel): bool
    {
        $stmt = $this->db->prepare('SELECT COUNT(*) FROM medecins WHERE telephone = :t');
        $stmt->execute([':t' => trim($tel)]);
        return (int)$stmt->fetchColumn() > 0;
    }

    public function creer(array $d): bool
    {
        $stmt = $this->db->prepare(
            'INSERT INTO medecins (nom, prenom, specialite, telephone, email, password, statut, photo)
             VALUES (:nom, :prenom, :specialite, :telephone, :email, :password, "disponible", :photo)'
        );
        return $stmt->execute([
            ':nom'        => htmlspecialchars(trim($d['nom'])),
            ':prenom'     => htmlspecialchars(trim($d['prenom'])),
            ':specialite' => htmlspecialchars(trim($d['specialite'])),
            ':telephone'  => trim($d['telephone']),
            ':email'      => strtolower(trim($d['email'])),
            ':password'   => $d['password'],  // hash bcrypt fourni par le controller
            ':photo'      => $d['photo'] ?? null,
        ]);
    }

    public function dernierID(): int
    {
        return (int)$this->db->lastInsertId();
    }

    public function affecterSousService(int $medecinId, int $ssId): bool
    {
        $stmt = $this->db->prepare(
            'INSERT INTO medecin_sous_service (medecin_id, sous_service_id, date_affectation)
             VALUES (:mid, :ssid, CURDATE())
             ON DUPLICATE KEY UPDATE date_affectation = date_affectation'
        );
        return $stmt->execute([':mid' => $medecinId, ':ssid' => $ssId]);
    }

    public function trouverParEmail(string $email)
    {
        $stmt = $this->db->prepare('SELECT * FROM medecins WHERE email = :e LIMIT 1');
        $stmt->execute([':e' => strtolower(trim($email))]);
        return $stmt->fetch();
    }

    public function trouverParId(int $id)
    {
        $stmt = $this->db->prepare('SELECT * FROM medecins WHERE id = :id');
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    public function getSousServiceMedecin(int $medecinId)
    {
        $stmt = $this->db->prepare(
            'SELECT ss.id AS ss_id, ss.nom AS ss_nom, ss.duree_estimee,
                    ss.capacite_horaire, ss.qr_code,
                    s.id AS service_id, s.nom AS service_nom, s.adresse
             FROM medecin_sous_service mss
             JOIN sous_services ss ON ss.id = mss.sous_service_id
             JOIN services s ON s.id = ss.service_id
             WHERE mss.medecin_id = :mid
             LIMIT 1'
        );
        $stmt->execute([':mid' => $medecinId]);
        return $stmt->fetch();
    }

    /* ════════════════════════════════════════════════════════
       LISTES POUR FORMULAIRES (mono-service)
    ════════════════════════════════════════════════════════ */

    public function getSousServicesActifs(): array
    {
        $stmt = $this->db->prepare(
            'SELECT id, nom, duree_estimee, capacite_horaire
             FROM sous_services
             WHERE statut = "actif"
             ORDER BY nom'
        );
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function trouverSousServiceParId(int $id)
    {
        $stmt = $this->db->prepare(
            'SELECT id, nom, statut FROM sous_services WHERE id = :id LIMIT 1'
        );
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    /* ════════════════════════════════════════════════════════
       DASHBOARD MÉDECIN
    ════════════════════════════════════════════════════════ */

    public function statsJour(int $ssId): array
    {
        $stmt = $this->db->prepare(
            'SELECT
               COUNT(*) AS total,
               SUM(statut = "traite") AS traitees,
               SUM(statut IN ("en_attente","confirme")) AS en_attente,
               SUM(statut = "absent") AS absentes,
               SUM(statut = "annule") AS annulees,
               COALESCE(ROUND(AVG(
                 CASE WHEN heure_debut_reelle IS NOT NULL
                       AND heure_fin_reelle IS NOT NULL
                      THEN TIMESTAMPDIFF(SECOND, heure_debut_reelle, heure_fin_reelle)
                 END
               )), 0) AS duree_moy_sec
             FROM consultations
             WHERE sous_service_id = :ss
               AND DATE(heure_emission) = CURDATE()'
        );
        $stmt->execute([':ss' => $ssId]);
        return $stmt->fetch() ?: [];
    }

    /**
     * Consultations du jour - basé sur heure_passage_estimee
     */
    public function consultationsDuJour(int $ssId, int $medecinId): array
    {
        $stmt = $this->db->prepare(
            'SELECT c.id, c.rang, c.statut, c.mode_prise,
                    c.heure_passage_estimee, c.heure_debut_reelle, c.heure_fin_reelle, c.motif,
                    p.nom AS patient_nom, p.prenom AS patient_prenom, p.telephone
             FROM consultations c
             JOIN patients p ON p.id = c.patient_id
             WHERE c.sous_service_id = :ss
               AND c.medecin_id = :mid
               AND DATE(c.heure_passage_estimee) = CURDATE()
               AND c.statut NOT IN ("annule", "absent")
             ORDER BY c.heure_passage_estimee ASC'
        );
        $stmt->execute([':ss' => $ssId, ':mid' => $medecinId]);
        return $stmt->fetchAll();
    }

    /**
     * Récupère les consultations d'un médecin sur une période donnée (pour le planning)
     */
    public function getConsultationsParPeriode(int $ssId, int $medecinId, string $dateDebut, string $dateFin): array
    {
        $stmt = $this->db->prepare(
            'SELECT c.id, c.rang, c.statut, c.mode_prise,
                    c.heure_passage_estimee, c.heure_debut_reelle, c.heure_fin_reelle, c.motif,
                    p.nom AS patient_nom, p.prenom AS patient_prenom, p.telephone
             FROM consultations c
             JOIN patients p ON p.id = c.patient_id
             WHERE c.sous_service_id = :ss
               AND c.medecin_id = :mid
               AND DATE(c.heure_passage_estimee) BETWEEN :date_debut AND :date_fin
               AND c.statut NOT IN ("annule", "absent")
             ORDER BY c.heure_passage_estimee ASC'
        );
        $stmt->execute([
            ':ss' => $ssId,
            ':mid' => $medecinId,
            ':date_debut' => $dateDebut,
            ':date_fin' => $dateFin
        ]);
        return $stmt->fetchAll();
    }

    public function planningMedecin(int $medecinId): array
    {
        $stmt = $this->db->prepare(
            'SELECT edt.id, edt.jour, edt.heure_debut, edt.heure_fin,
                    edt.nb_creneaux, ss.nom AS ss_nom, s.nom AS service_nom
             FROM emplois_du_temps edt
             JOIN sous_services ss ON ss.id = edt.sous_service_id
             JOIN services s ON s.id = ss.service_id
             WHERE edt.medecin_id = :mid
               AND edt.jour BETWEEN
                   DATE(DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY))
                   AND DATE(DATE_ADD(DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY), INTERVAL 6 DAY))
             ORDER BY edt.jour, edt.heure_debut'
        );
        $stmt->execute([':mid' => $medecinId]);
        return $stmt->fetchAll();
    }

    /* ════════════════════════════════════════════════════════
       ACTIONS SUR LES CONSULTATIONS
    ════════════════════════════════════════════════════════ */

    public function demarrerConsultation(int $consultationId): bool
    {
        $stmt = $this->db->prepare(
            'UPDATE consultations
             SET statut = "en_cours", heure_debut_reelle = NOW()
             WHERE id = :id AND statut IN ("en_attente", "confirme")'
        );
        return $stmt->execute([':id' => $consultationId]) && $stmt->rowCount() > 0;
    }

    public function terminerConsultation(int $consultationId): bool
    {
        // Accepte en_cours mais aussi en_attente/confirme si le médecin
        // clique sur Terminer sans avoir démarré explicitement
        $stmt = $this->db->prepare(
            'UPDATE consultations
             SET statut = "traite",
                 heure_debut_reelle = COALESCE(heure_debut_reelle, NOW()),
                 heure_fin_reelle   = NOW()
             WHERE id = :id AND statut IN ("en_attente", "confirme", "en_cours")'
        );
        return $stmt->execute([':id' => $consultationId]) && $stmt->rowCount() > 0;
    }

    public function marquerAbsent(int $consultationId): bool
    {
        $stmt = $this->db->prepare(
            'UPDATE consultations 
             SET statut = "absent" 
             WHERE id = :id AND statut IN ("en_attente", "confirme", "en_cours")'
        );
        return $stmt->execute([':id' => $consultationId]);
    }

    public function annulerConsultation(int $consultationId): bool
    {
        $stmt = $this->db->prepare(
            'UPDATE consultations 
             SET statut = "annule" 
             WHERE id = :id AND statut NOT IN ("traite")'
        );
        return $stmt->execute([':id' => $consultationId]);
    }

    public function annulerToutesConsultations(int $medecinId): bool
    {
        $stmt = $this->db->prepare(
            'UPDATE consultations 
             SET statut = "annule" 
             WHERE medecin_id = :mid 
               AND DATE(heure_emission) = CURDATE() 
               AND statut NOT IN ("traite", "annule", "absent")'
        );
        return $stmt->execute([':mid' => $medecinId]);
    }

    public function majStatutConsultation(int $id, string $statut): bool
    {
        $allowed = ['en_attente', 'confirme', 'en_cours', 'traite', 'annule', 'absent'];
        if (!in_array($statut, $allowed)) {
            return false;
        }
        $stmt = $this->db->prepare('UPDATE consultations SET statut = :s WHERE id = :id');
        return $stmt->execute([':s' => $statut, ':id' => $id]);
    }

    /* ════════════════════════════════════════════════════════
       GESTION DU PROFIL
    ════════════════════════════════════════════════════════ */

    public function mettreAJourProfil(int $id, string $nom, string $prenom, string $telephone): bool
    {
        $stmt = $this->db->prepare(
            'UPDATE medecins SET nom = :nom, prenom = :prenom, telephone = :telephone WHERE id = :id'
        );
        return $stmt->execute([
            ':nom' => htmlspecialchars(trim($nom)),
            ':prenom' => htmlspecialchars(trim($prenom)),
            ':telephone' => trim($telephone),
            ':id' => $id
        ]);
    }

    public function mettreAJourEmail(int $id, string $email): bool
    {
        $stmt = $this->db->prepare('UPDATE medecins SET email = :email WHERE id = :id');
        return $stmt->execute([
            ':email' => strtolower(trim($email)),
            ':id' => $id
        ]);
    }

    public function mettreAJourMotDePasse(int $id, string $password): bool
    {
        $stmt = $this->db->prepare('UPDATE medecins SET password = :password WHERE id = :id');
        return $stmt->execute([
            ':password' => password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]),
            ':id' => $id
        ]);
    }

    public function mettreAJourPhoto(int $id, ?string $photoPath): bool
    {
        $stmt = $this->db->prepare('UPDATE medecins SET photo = :photo WHERE id = :id');
        return $stmt->execute([
            ':photo' => $photoPath,
            ':id' => $id
        ]);
    }

    public function verifierMotDePasse(int $id, string $password): bool
    {
        $stmt = $this->db->prepare('SELECT password FROM medecins WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $hash = $stmt->fetchColumn();
        return password_verify($password, $hash);
    }

    /* ════════════════════════════════════════════════════════
       JOURS DE TRAVAIL DU MÉDECIN
    ════════════════════════════════════════════════════════ */

    public function getJoursTravailMedecin(int $medecinId): array
    {
        $stmt = $this->db->prepare(
            'SELECT jour_semaine FROM medecin_jours_travail 
             WHERE medecin_id = :mid AND actif = 1'
        );
        $stmt->execute([':mid' => $medecinId]);
        $result = $stmt->fetchAll();
        return array_column($result, 'jour_semaine');
    }

    public function sauvegarderJoursTravailMedecin(int $medecinId, array $jours): bool
    {
        try {
            $stmt = $this->db->prepare('DELETE FROM medecin_jours_travail WHERE medecin_id = :mid');
            $stmt->execute([':mid' => $medecinId]);

            $stmt = $this->db->prepare(
                'INSERT INTO medecin_jours_travail (medecin_id, jour_semaine, actif)
                 VALUES (:mid, :jour, 1)'
            );

            foreach ($jours as $jour) {
                $stmt->execute([':mid' => $medecinId, ':jour' => (int)$jour]);
            }
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
}