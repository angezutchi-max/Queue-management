<?php
/**
 * admin.php — Point d'entrée espace administrateur (directeur)
 */

if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/helpers/AuthHelper.php';
require_once __DIR__ . '/config/app.php';

if (!AuthHelper::estAdmin()) {
    header('Location: index.php?action=login&error=acces_refuse');
    exit;
}

AuthHelper::verifierSession('index.php?action=login');

error_reporting(E_ALL);
ini_set('display_errors', 1);

$action = $_GET['action'] ?? 'dashboard';

$allowedActions = [
    'dashboard',
    'sauvegarder_hopital',
    'creer_utilisateur',   // GET → affiche formulaire  |  POST → traite
    'toggle_statut',
    // Sous-services
    'creer_ss',
    'modifier_ss',
    'supprimer_ss',
    'toggle_statut_ss',
];

if (!in_array($action, $allowedActions, true)) {
    http_response_code(404);
    die('Page introuvable.');
}

require_once __DIR__ . '/controllers/AdminController.php';
$ctrl = new AdminController();

switch ($action) {
    case 'dashboard':
        $ctrl->afficherDashboard();
        break;

    case 'sauvegarder_hopital':
        $ctrl->sauvegarderHopital();
        break;

    case 'creer_utilisateur':
        // GET  → afficher le formulaire dédié
        // POST → traiter l'insertion
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $ctrl->creerUtilisateur();
        } else {
            $ctrl->afficherFormulaireUtilisateur();
        }
        break;

    case 'toggle_statut':
        $ctrl->toggleStatutUtilisateur();
        break;

    case 'creer_ss':
        $ctrl->creerSousService();
        break;

    case 'modifier_ss':
        $ctrl->modifierSousService();
        break;

    case 'supprimer_ss':
        $ctrl->supprimerSousService();
        break;

    case 'toggle_statut_ss':
        $ctrl->toggleStatutSousService();
        break;

    default:
        $ctrl->afficherDashboard();
}